/*
* JohnyDepp
* https://github.com/muicss/johnnydepp
*/
this.depp||function(n,e){depp=function(){var n={},u=function(){},f={},o={},a={},s={},d={};function p(n){throw new Error("Depp Error: "+n)}function r(n,e){var t=function r(n,i){i=i||[];var c=[],o=[];return n.forEach(function(t){if(0<=i.indexOf(t)&&p("Circular reference"),!(t in f))return c.push("#"+t);f[t].forEach(function(n){if("#"==n[0]){var e=i.slice();e.push(t),e=r([n.slice(1)],e),c=c.concat(e[0]),o=o.concat(e[1])}else o.push(n)})}),[c,o]}(n);t[0].length?i(t[0],function(){r(n,e)}):e(t[1])}function i(n,t){var e,r,i=n.length,c=i;if(0==i)return t();for(e=function(n,e){if(e)return t(n);--c||t()};i--;)(r=n[i])in a?e(r,a[r]):(o[r]=o[r]||[]).push(e)}function l(n,e){var t=o[n];if(a[n]=e,t)for(;t.length;)t[0](n,e),t.splice(0,1)}return n.define=function(n){var e;for(var t in n)t in f&&p("Bundle already defined"),e=n[t],f[t]=e.push?e:[e],l("#"+t)},n.config=function(n){for(var e in n)d[e]=n[e]},n.require=function(n,e,t){r(n=n.push?n:[n],function(n){i(n,function(n){n?(t||u)(n):(e||u)()}),n.forEach(function(n){var t,r,i,c,e,o,f;n in s||(s[n]=!0,t=n,r=l,e=document,o=d.before||u,f=t.replace(/^(css|img)!/,""),/(^css!|\.css$)/.test(t)?(i=!0,(c=e.createElement("link")).rel="stylesheet",c.href=f):/(^img!|\.(png|gif|jpg|svg)$)/.test(t)?(c=e.createElement("img")).src=f:((c=e.createElement("script")).src=t,c.async=!1),c.onload=c.onerror=c.onbeforeload=function(n){var e=n.type[0];if(i&&"hideFocus"in c)try{c.sheet.cssText.length||(e="e")}catch(n){18!=n.code&&(e="e")}if("b"==e){if(!n.defaultPrevented)return;e="e"}r(t,"e"==e)},o(t,c),e.head.appendChild(c))})})},n.done=function(n){f[n]=[],l("#"+n)},n.isDefined=function(n){return n in f},n.reset=function(){f={},o={},a={},s={},d={}},n}(),(e=n.createEvent("HTMLEvents")).initEvent?e.initEvent("depp-load",!1,!1):e=new Event("depp-load"),n.dispatchEvent(e)}(document);

depp.define({
    'fommerce-slick': [fommerce.url + 'assets/public/js/slick.min.js?v=' + fommerce.version],
    'fommerce-velocity': [fommerce.url + 'assets/public/js/velocity.bundle.min.js?v=' + fommerce.version]
});

jQuery(document).ready(function() {

    $ = jQuery.noConflict();

    $(document).on('click', '.modal .modal-close', function() {
        $('.modal').removeClass('active');
    });

    fommerce.isObj=function(val){return null!==val&&"object"==typeof val&&val.constructor!==Array};
    fommerce.merge=function(tgt,src){var i;for(i in src)fommerce.isObj(tgt[i])&&fommerce.isObj(src[i])?fommerce.merge(tgt[i],src[i]):Vue.set(tgt,i,src[i])};
    fommerce.set=function(key,val,tgt){var i,ii,obj;if(key){for(obj=tgt,path=key.split("."),key=path.pop(),i=0,ii=path.length;i<ii;i++)tgt[path[i]]||Vue.set(tgt,path[i],{}),tgt=tgt[path[i]];fommerce.isObj(tgt[key])&&fommerce.isObj(val)?fommerce.merge(tgt[key],val):tgt[key]=val}};
    fommerce.get=function(key,tgt){var i,ii,obj;if(key){for(path=key.split("."),i=0,ii=path.length;i<ii;i++){if(!tgt[path[i]])return tgt[path[i]];tgt=tgt[path[i]]}return tgt}};

    fommerce.images = {
        new: fommerce.url + 'assets/public/img/new.svg',
        fire: fommerce.url + 'assets/public/img/fire.svg',
        map: fommerce.url + 'assets/public/img/location.svg',
        star: fommerce.url + 'assets/public/img/star.svg',
        man: fommerce.url + 'assets/public/img/man.svg',
        rocket: fommerce.url + 'assets/public/img/rocket.svg',
        shirt: fommerce.url + 'assets/public/img/shirt.svg',
        custom: ''
    };

    fommerce.notificationThemes = {
        default: {
            message: '<p>Someone from {city} just bought</p><p><b>{productname}</b></p>',
            corner: '{x}',
            heading: '',
            textColor: '#222',
            background: '#fff',
            borderRadius: 5
        },
        dark: {
            textColor: '#fff',
            background: '#485168',
            borderRadius: 5
        },
        ios: {
            message: '<b>Sale</b><p><b>{productname}</b> has been sold for {price}',
            corner: '{timeago}',
            heading: 'MESSAGE',
            textColor: '#202020',
            background: 'rgba(0,0,0,0)',
            borderRadius: 12
        },
        sticky: {
            textColor: '#313131',
            background: '#FBE471',
            borderRadius: 2
        },
        glass: {
            textColor: '#444',
            background: 'rgba(150,150,150,0.1)',
            borderRadius: 5
        },
        wood: {
            textColor: '#c37f64',
            background: fommerce.url + 'assets/public/img/wood.jpg',
            borderRadius: 5
        }
    };

    fommerce.feedThemes = {
        default: {
            textColor: '#222',
            slideBackground: '#fff',
            borderRadius: 5,
            shadow: { enabled: true, horizontal: 0, vertical: 1, blur: 6, spread: 0, color: 'rgba(32,33,36,0.28)' }
        },
        dark: {
            textColor: '#fff',
            slideBackground: '#485168',
            borderRadius: 5,
            shadow: { enabled: false }
        },
        ios: {
            textColor: '#202020',
            slideBackground: 'rgba(0,0,0,0)',
            borderRadius: 12,
            shadow: { enabled: true, horizontal: 0, vertical: 2, blur: 5, spread: 0, color: 'rgba(0, 0, 0, 0.06)' }
        },
        sticky: {
            textColor: '#313131',
            slideBackground: '#FBE471',
            borderRadius: 2,
            shadow: { enabled: true, horizontal: 5, vertical: 5, blur: 2, spread: 0, color: 'rgba(187, 104, 0, 0.1)' }
        },
        glass: {
            textColor: '#444',
            slideBackground: 'rgba(150,150,150,0.1)',
            borderRadius: 5,
            shadow: { enabled: true, horizontal: 0, vertical: 0, blur: 20, spread: 0, color: 'rgba(0,0,0,0.5)' }
        },
        wood: {
            textColor: '#c37f64',
            slideBackground: fommerce.url + 'assets/public/img/wood.jpg',
            borderRadius: 5,
            shadow: { enabled: false }
        }
    };

    fommerce.editorOpts = {
        autogrow: true,
        semantic: false,
        svgPath: fommerce.url + 'assets/admin/fonts/trumbowyg.svg'
    };

    fommerce.sliderOpts = function(feed) {
        return {
            arrows: false,
            dots: false,
            infinite: true,
            vertical: true,
            verticalSwiping: true,
            verticalReverse: (feed.direction == 'down') ? true : false,
            slidesToShow: parseInt(feed.slidesToShow),
            slidesToScroll: parseInt(feed.slidesToScroll),
            autoplay: true,
            autoplaySpeed: parseFloat(feed.interval) * 1000,
            cssEase: 'cubic-bezier(0.785, 0.135, 0.15, 0.86)'
        };
    };

    Vue.component('fommerce-config', {
        template: '#fommerce-config',
        props: {
            config: Object
        },
        data: function() {
            return {
                message: '',
                tab: sessionStorage.getItem('fmc-config-tab') ? sessionStorage.getItem('fmc-config-tab') : 'license'
            }
        },
        methods: {
            selectTab: function(tab) {
                this.tab = tab;
                this.activeEditor = '';
                sessionStorage.setItem('fmc-config-tab', tab);
            },
            licenseCheck: function(action) {
                var self = this;

                var button = $(event.target);
                self.message = '';
                var nonce = $('input[name=_fmcnonce]').val();
                button.addClass('loading').prop('disabled', true);

                var data = {
                    action: 'fommerce_license',
                    nonce: nonce,
                    license_action: action,
                    code: this.config.licenseKey
                };

                $.post(fommerce.ajaxurl, data, function(response) {
                    if (response.license == 'false') {
                        self.config.licenseKey = '';
                    }
                    button.removeClass('loading').prop('disabled', false);
                    self.config.license = response.license;
                    self.message = response.message;
                }, 'json');

            }
        }
    });

    Vue.component('fommerce-feeds', {
        template: '#fommerce-feeds',
        props: {
            feed: Object,
            selected: Number
        },
        data: function() {
            return {
                tab: sessionStorage.getItem('fmc-feeds-tab') ? sessionStorage.getItem('fmc-feeds-tab') : 'general',
                images: fommerce.images,
                themes: fommerce.feedThemes,
                activeEditor: ''
            }
        },
        mounted() {
            var self = this;

            depp.require('fommerce-slick', function() {

                $('.fomo-feeds-' + self.feed.id).not('.slick-initialized').slick(fommerce.sliderOpts(self.feed));

                $(window).on('resize orientationchange', function() {
                    $('.fomo-feeds-' + self.feed.id).slick('refresh');
                });
    
            });

            $('#message' + this.feed.id + '-editor').html(self.feed.message).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.feed.message = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'message';
            });

            $('#link' + this.feed.id + '-editor').html(self.feed.link).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.feed.link = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'link';
            });

            this.$parent.selectize(self, $('.product' + this.feed.id + '-selectize'), { model: 'feed.products.selectProducts', ajax: 'fommerce_search',
                selectize: {
                    render: {
                        option: function(item, escape) {
                            return '<div class="sel-option"><div><img src="' + escape(item.image) + '" /></div><div class="sel-content"><b>' + escape(item.name) + '</b><br>Price: ' + item.price + '</div></div>'
                        }
                    }
                }
            });
            this.$parent.selectize(self, $('.exclude' + this.feed.id + '-selectize'), { model: 'feed.products.excludeProducts', ajax: 'fommerce_search',
                selectize: {
                    render: {
                        option: function(item, escape) {
                            return '<div class="sel-option"><div><img src="' + escape(item.image) + '" /></div><div class="sel-content"><b>' + escape(item.name) + '</b><br>Price: ' + item.price + '</div></div>'
                        }
                    }
                }
            });
            this.$parent.selectize(self, $('.orderstatus' + this.feed.id + '-selectize'), { model: 'feed.products.orderStatus' });
            this.$parent.selectize(self, $('.category' + this.feed.id + '-selectize'), { model: 'feed.products.categories', ajax: 'fommerce_search_cat' });
            this.$parent.colorPicker(self, $('.text' + this.feed.id + '-colorpicker'), { model: 'feed.textColor' });
            this.$parent.colorPicker(self, $('.img-bg' + this.feed.id + '-colorpicker'), { model: 'feed.imageBackground' });
            this.$parent.colorPicker(self, $('.slide-bg' + this.feed.id + '-colorpicker'), { model: 'feed.slideBackground' });
            this.$parent.colorPicker(self, $('.widget-bg' + this.feed.id + '-colorpicker'), { model: 'feed.widgetBackground' });
            this.$parent.colorPicker(self, $('.border' + this.feed.id + '-colorpicker'), { model: 'feed.borderColor' });
            this.$parent.colorPicker(self, $('.shadow' + this.feed.id + '-colorpicker'), { model: 'feed.shadow.color' });

            var cp = new ClipboardJS('#feed' + this.feed.id + '-shortcode');
        },
        watch: {
            'feed': {
                handler: function(val, oldVal) {
                    $('.fomo-feeds-' + this.feed.id).slick('unslick').slick(this.sliderOpts);
                    setTimeout(function() { $(window).trigger('resize'); }, 0)
                },
                deep: true
            },
            'feed.theme': function() {
                var self = this;
                var theme = self.feed.theme.replace('woo-notify-theme-' , '');
                fommerce.merge(self.feed, self.themes[theme]);
            },
            'feed.shadow': {
                handler: function(val, oldVal) {
                    this.feed.shadow.text = (this.feed.shadow.enabled) ? this.feed.shadow.horizontal + 'px ' + this.feed.shadow.vertical + 'px ' + this.feed.shadow.blur + 'px ' + this.feed.shadow.spread + 'px ' + this.feed.shadow.color : 'none';
                },
                deep: true
            }
        },
        computed: {
            isActive: function() {
                return this.feed.id == this.selected;
            },
            shortcode: function() {
                return '[fommerce addon="feed" id="' + this.feed.id + '"]';
            },
            containerStyle: function() {
                var styles = {
                    borderRadius: this.feed.borderRadius + 'px'
                };
                if (this.feed.widgetBackground.indexOf('/') !== -1) {
                    styles['background-image'] = 'url(' + this.feed.widgetBackground + ')';
                } else {
                    styles['background'] = this.feed.widgetBackground;
                }

                return styles;
            },
            notifyStyle: function() {
                var styles = {
                    color: this.feed.textColor,
                    width: 'calc(100% - ' + (this.feed.spacing * 2) + 'px)',
                    margin: this.feed.spacing + 'px',
                    borderRadius: this.feed.borderRadius + 'px',
                    'box-shadow': this.feed.shadow.text
                };

                if (this.feed.slideBackground.indexOf('http') === 0) {
                    styles['background-image'] = 'url(' + this.feed.slideBackground + ')';
                } else {
                    styles['background'] = this.feed.slideBackground;
                }

                return styles;
            },
            imageContainerStyle: function() {
                return {
                    background: this.feed.imageBackground,
                    margin: this.feed.imageMargin + 'px',
                    padding: this.feed.imagePadding + 'px',
                    borderRadius: this.feed.borderRadius + 'px'
                };
            },
            imageStyle: function() {
                return {
                    width: this.feed.imageSize + 'px',
                    height: this.feed.imageSize + 'px'
                };
            },
            textStyle: function() {
                return {
                    'padding-top': this.feed.padding.top + 'px ',
                    'padding-right': this.feed.padding.right + 'px',
                    'padding-bottom': this.feed.padding.bottom + 'px',
                    'padding-left': this.feed.padding.left + 'px'
                };
            }
        },
        methods: {
            selectTab: function(tab) {
                this.tab = tab;
                sessionStorage.setItem('fmc-feeds-tab', tab);
            },
            uploadImage: function(models) {
                var self = this;

                var send_attachment_bkp = wp.media.editor.send.attachment;
                wp.media.editor.send.attachment = function(props, attachment) {
                    models.forEach(function(model) {
                        fommerce.set(model, attachment.url, self);
                    });
                    wp.media.editor.send.attachment = send_attachment_bkp;
                }

                wp.media.editor.open();
                return false;
            },
            insertPlaceholder: function(placeholder, editor) {
                $('#' + editor + this.feed.id + '-editor').trumbowyg('execCmd', { cmd: 'insertText', param: '{' + placeholder + '}', forceCss: false });
            },
            editPlaceholder: function(placeholder, editor) {
                this.feed.placeholder = placeholder;
                $('.place-modal').addClass('active');
                setTimeout(function() {
                    $('.place-options').find('textarea').each(function() {
                        var offset = this.offsetHeight - this.clientHeight;
                        $(this).css('height', 'auto').css('height', this.scrollHeight + offset);
                    });
                }, 0);
            },
            resizeTextarea: function(ev) {
                var offset = ev.target.offsetHeight - ev.target.clientHeight;
                $(ev.target).css('height', 'auto').css('height', ev.target.scrollHeight + offset);
            }
        }
    });

    Vue.component('fommerce-notifications', {
        template: '#fommerce-notifications',
        props: {
            notification: Object,
            selected: Number
        },
        data: function() {
            return {
                tab: sessionStorage.getItem('fmc-notifications-tab') ? sessionStorage.getItem('fmc-notifications-tab') : 'general',
                images: fommerce.images,
                themes: fommerce.notificationThemes,
                activeEditor: ''
            }
        },
        mounted() {
            var self = this;
            $('#message' + this.notification.id + '-editor').html(self.notification.message).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.notification.message = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'message';
            });
            $('#heading' + this.notification.id + '-editor').html(self.notification.heading).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.notification.heading = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'heading';
            });
            $('#corner' + this.notification.id + '-editor').html(self.notification.corner).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.notification.corner = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'corner';
            });
            $('#link' + this.notification.id + '-editor').html(self.notification.link).trumbowyg(fommerce.editorOpts).on('tbwchange', function(e) { self.notification.link = $(e.target).trumbowyg('html'); }).on('tbwfocus', function() {
                self.activeEditor = 'link';
            });
            this.$parent.selectize(self, $('.product' + this.notification.id + '-selectize'), { model: 'notification.products.selectProducts', ajax: 'fommerce_search',
                selectize: {
                    render: {
                        option: function(item, escape) {
                            return '<div class="sel-option"><div><img src="' + escape(item.image) + '" /></div><div class="sel-content"><b>' + escape(item.name) + '</b><br>Price: ' + item.price + '</div></div>'
                        }
                    }
                }
            });
            this.$parent.selectize(self, $('.exclude' + this.notification.id + '-selectize'), { model: 'notification.products.excludeProducts', ajax: 'fommerce_search',
                selectize: {
                    render: {
                        option: function(item, escape) {
                            return '<div class="sel-option"><div><img src="' + escape(item.image) + '" /></div><div class="sel-content"><b>' + escape(item.name) + '</b><br>Price: ' + item.price + '</div></div>'
                        }
                    }
                }
            });
            this.$parent.selectize(self, $('.orderstatus' + this.notification.id + '-selectize'), { model: 'notification.products.orderStatus', });
            this.$parent.selectize(self, $('.category' + this.notification.id + '-selectize'), { model: 'notification.products.categories', ajax: 'fommerce_search_cat' });
            this.$parent.colorPicker(self, $('.text' + this.notification.id + '-colorpicker'), { model: 'notification.textColor' });
            this.$parent.colorPicker(self, $('.bg' + this.notification.id + '-colorpicker'), { model: 'notification.background' });
            this.$parent.colorPicker(self, $('.img-bg' + this.notification.id + '-colorpicker'), { model: 'notification.imageBackground' });
        },
        computed: {
            isActive: function() {
                return this.notification.id == this.selected;
            },
            containerStyle: function() {
                var styles = {
                    'font-size': this.notification.fontSize + 'px'
                };
                return styles;
            },
            singleNotifyStyle: function() {
                var styles = {
                    'max-width': this.notification.width + 'px'
                };
                if (this.notification.position.indexOf('top') > -1) {
                    styles['top'] = this.notification.margin.vertical + 'px';
                }
                if (this.notification.position.indexOf('bottom') > -1) {
                    styles['bottom'] = this.notification.margin.vertical + 'px';
                }
                if (this.notification.position.indexOf('left') > -1) {
                    styles['left'] = this.notification.margin.horizontal + 'px';
                }
                if (this.notification.position.indexOf('right') > -1) {
                    styles['right'] = this.notification.margin.horizontal + 'px';
                }
                return styles;
            },
            notifyStyle: function () {

                var styles = {
                    color: this.notification.textColor,
                    borderRadius: this.notification.borderRadius + 'px'
                };

                if (this.notification.background.indexOf('/') !== -1) {
                    styles['background-image'] = 'url(' + this.notification.background + ')';
                } else {
                    styles['background'] = this.notification.background;
                }

                return styles;
            },
            imageContainerStyle: function() {
                return {
                    background: this.notification.imageBackground,
                    margin: this.notification.imageMargin + 'px',
                    padding: this.notification.imagePadding + 'px',
                    borderRadius: this.notification.borderRadius + 'px'
                };
            },
            imageStyle: function() {
                return {
                    width: this.notification.imageSize + 'px',
                    height: this.notification.imageSize + 'px'
                };
            },
            textStyle: function() {
                return {
                    'padding-top': this.notification.padding.top + 'px ',
                    'padding-right': this.notification.padding.right + 'px',
                    'padding-bottom': this.notification.padding.bottom + 'px',
                    'padding-left': this.notification.padding.left + 'px'
                };
            }
        },
        watch: {
            'notification.theme': function() {
                var self = this;
                var theme = self.notification.theme.replace('woo-notify-theme-' , '');
                fommerce.merge(self.notification, self.themes[theme]);
                $('#message' + this.notification.id + '-editor').trumbowyg('html', this.notification.message);
                $('#heading' + this.notification.id + '-editor').trumbowyg('html', this.notification.heading);
                $('#corner' + this.notification.id + '-editor').trumbowyg('html', this.notification.corner);
            },
            'notification.entryAnim': function() {
                var self = this;
                depp.require('fommerce-velocity', function() {
                    $('.woo-notify-single').velocity('transition.' + self.notification.entryAnim, { duration: self.notification.animSpeed });
                });
            },
            'notification.exitAnim': function() {
                var self = this;
                depp.require('fommerce-velocity', function() {
                    $('.woo-notify-single').velocity('transition.' + self.notification.exitAnim, { duration: self.notification.animSpeed, complete: function() { $('.woo-notify-single').velocity('stop').velocity('transition.' + self.notification.entryAnim, { duration: self.notification.animSpeed }); } });
                });
            },
        },
        methods: {
            selectTab: function(tab) {
                this.tab = tab;
                this.activeEditor = '';
                sessionStorage.setItem('fmc-notifications-tab', tab);
            },
            uploadImage: function(models) {
                var self = this;

                var send_attachment_bkp = wp.media.editor.send.attachment;
                wp.media.editor.send.attachment = function(props, attachment) {
                    models.forEach(function(model) {
                        fommerce.set(model, attachment.url, self);
                    });
                    wp.media.editor.send.attachment = send_attachment_bkp;
                }

                wp.media.editor.open();
                return false;
            },
            insertPlaceholder: function(placeholder, editor) {
                $('#' + editor + this.notification.id + '-editor').trumbowyg('execCmd', { cmd: 'insertText', param: '{' + placeholder + '}', forceCss: false });
            },
            editPlaceholder: function(placeholder, editor) {
                this.notification.placeholder = placeholder;
                $('.place-modal').addClass('active');
                setTimeout(function() {
                    $('.place-options').find('textarea').each(function() {
                        var offset = this.offsetHeight - this.clientHeight;
                        $(this).css('height', 'auto').css('height', this.scrollHeight + offset);
                    });
                }, 0);
            },
            resizeTextarea: function(ev) {
                var offset = ev.target.offsetHeight - ev.target.clientHeight;
                $(ev.target).css('height', 'auto').css('height', ev.target.scrollHeight + offset);
            }
        },
    });

    var app = new Vue({
        el: '#fommerce-app',
        data: {
            addon: fommerce.addon,
            selected: fommerce.options[fommerce.addon][0] ? fommerce.options[fommerce.addon][0].id : 0,
            notifications: fommerce.options.notifications,
            feeds: fommerce.options.feeds,
            config: fommerce.options.config
        },
        methods: {
            submit: function() {

                var button = $(event.target);
                var nonce = $('input[name=_fmcnonce]').val();
                button.addClass('loading').prop('disabled', true);

                var data = {
                    action: 'fommerce_save',
                    nonce: nonce,
                    addon: this.addon,
                    data: JSON.stringify(this[this.addon])
                };

                $.post(fommerce.ajaxurl, data, function(response) {
                    if (response.success) {
                        button.removeClass('loading').width(button.width()).html('<i class="ft ft-check-circle"></i>').prop('disabled', false);
                        setTimeout(function() {
                            button.html('<i class="ft ft-save mr-1"></i> Save Changes');
                        }, 1000);
                    } else {
                        button.removeClass('loading').prop('disabled', false);
                    }
                }, 'json');

            },
            addpanel: function() {
                var copy = JSON.parse(JSON.stringify(fommerce['defaults'][this.addon]));
                copy.id = this.getId();
                this[this.addon].push(copy);
                this.selected = copy.id;
            },
            getId: function() {
                var ids = this[this.addon].map(function(item) { return item.id });
                return (ids.length) ? Math.max.apply(Math, ids) + 1 : 1;
            },
            toggleModal: function(el) {
                $(el).toggleClass('active');
            },
            togglePreview: function() {
                $('.preview-content-' + this.selected).slideToggle(400, function() {
                    setTimeout(function() { $(window).trigger('resize'); }, 0);
                });
            },
            toggle: function(id) {
                this.selected = (this.selected == id) ? 0 : id;
                setTimeout(function() { $(window).trigger('resize'); }, 0);
            },
            remove: function(id) {
                var c = confirm("Are you sure?");
                if (c == true) {
                    var index = this[this.addon].findIndex(function(addon) {
                        return addon.id == id;
                    });
                    this[this.addon].splice(index, 1);
                    index = Math.max(index - 1, 0);
                    this.selected = this[this.addon][index] ? this[this.addon][index].id : 0;
                }
            },
            selectize: function(self, el, options = {}) {

                var defaults = {
                    plugins: ['remove_button'],
                    valueField: 'id',
                    labelField: 'name',
                    searchField: 'name',
                    dropdownParent: 'body',
                    create: false,
                    items: fommerce.get(options.model, self).map(function(item) { return item.id }),
                    options: fommerce.get(options.model, self),
                    onChange: function(value) {
                        var select = this;
                        var result = [];
                        this.items.forEach(function(item) {
                            result.push(select.options[item]);
                        });
                        fommerce.set(options.model, result, self);
                    }
                };

                if (options.ajax && options.ajax.length > 0) {
                    defaults.load = function(query, callback) {
                        
                        if (!query.length) {
                            return callback();
                        }

                        $.ajax({
                            url: fommerce.ajaxurl,
                            type: 'POST',
                            data: {
                                action: options.ajax,
                                keyword: encodeURIComponent(query)
                            },
                            error: function() {
                                callback();
                            },
                            success: function(res) {
                                callback(res);
                            }
                        });
                    }
                }

                el.selectize(defaults, $.extend(defaults, options.selectize));

            },
            colorPicker: function(self, el, options = {}) {
                var pickr = Pickr.create({el:el[0],position:"bottom-end",useAsButton:!0,components:{preview:!1,opacity:!0,hue:!0,useAsButton:!0,interaction:{hex:!0,rgba:!0,hsla:!1,hsva:!1,cmyk:!1,input:!0,clear:!1,save:!0}}});
                pickr.on('changestop', function(instance) {
                    var color = (instance._color.a === 1) ? instance._color.toHEXA().toString() : instance._color.toRGBA().toString();
                    fommerce.set(options.model, color, self);
                });
            }
        }
    });

});