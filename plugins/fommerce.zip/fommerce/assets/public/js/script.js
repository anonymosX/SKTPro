/*
* JohnyDepp
* https://github.com/muicss/johnnydepp
*/
this.depp||function(n,e){depp=function(){var n={},u=function(){},f={},o={},a={},s={},d={};function p(n){throw new Error("Depp Error: "+n)}function r(n,e){var t=function r(n,i){i=i||[];var c=[],o=[];return n.forEach(function(t){if(0<=i.indexOf(t)&&p("Circular reference"),!(t in f))return c.push("#"+t);f[t].forEach(function(n){if("#"==n[0]){var e=i.slice();e.push(t),e=r([n.slice(1)],e),c=c.concat(e[0]),o=o.concat(e[1])}else o.push(n)})}),[c,o]}(n);t[0].length?i(t[0],function(){r(n,e)}):e(t[1])}function i(n,t){var e,r,i=n.length,c=i;if(0==i)return t();for(e=function(n,e){if(e)return t(n);--c||t()};i--;)(r=n[i])in a?e(r,a[r]):(o[r]=o[r]||[]).push(e)}function l(n,e){var t=o[n];if(a[n]=e,t)for(;t.length;)t[0](n,e),t.splice(0,1)}return n.define=function(n){var e;for(var t in n)t in f&&p("Bundle already defined"),e=n[t],f[t]=e.push?e:[e],l("#"+t)},n.config=function(n){for(var e in n)d[e]=n[e]},n.require=function(n,e,t){r(n=n.push?n:[n],function(n){i(n,function(n){n?(t||u)(n):(e||u)()}),n.forEach(function(n){var t,r,i,c,e,o,f;n in s||(s[n]=!0,t=n,r=l,e=document,o=d.before||u,f=t.replace(/^(css|img)!/,""),/(^css!|\.css$)/.test(t)?(i=!0,(c=e.createElement("link")).rel="stylesheet",c.href=f):/(^img!|\.(png|gif|jpg|svg)$)/.test(t)?(c=e.createElement("img")).src=f:((c=e.createElement("script")).src=t,c.async=!1),c.onload=c.onerror=c.onbeforeload=function(n){var e=n.type[0];if(i&&"hideFocus"in c)try{c.sheet.cssText.length||(e="e")}catch(n){18!=n.code&&(e="e")}if("b"==e){if(!n.defaultPrevented)return;e="e"}r(t,"e"==e)},o(t,c),e.head.appendChild(c))})})},n.done=function(n){f[n]=[],l("#"+n)},n.isDefined=function(n){return n in f},n.reset=function(){f={},o={},a={},s={},d={}},n}(),(e=n.createEvent("HTMLEvents")).initEvent?e.initEvent("depp-load",!1,!1):e=new Event("depp-load"),n.dispatchEvent(e)}(document);

depp.define({
    'fommerce-slick': [fommerce.url + 'assets/public/js/slick.min.js?v=' + fommerce.version],
    'fommerce-velocity': [fommerce.url + 'assets/public/js/velocity.bundle.min.js?v=' + fommerce.version]
});

(function($) {

    $.fn.fmcNotification = function() {
        var self = $(this);
        var notifsCount = self.find('.woo-notify-single').length;
        var options = self.data('options');

        var initialDelay = randomNumber(options.displayDelay.from, options.displayDelay.to);

        if (self.find('.fommerce-audio').length) {
            var audio = self.find(".fommerce-audio")[0];
        }

        depp.require('fommerce-velocity', function() {

            var showInterval = function() {
                var next = true;
                var index = parseInt(self.attr('data-index'));
                var notifsCount = self.find('.woo-notify-single').length;
                showNotification(index);
    
                if (index == (notifsCount - 1)) {
                    next = options.loop;
                    index = 0;
                } else {
                    index = index + 1;
                }
    
                if (next) {
                    self.attr('data-index', index);
                    var randomDelay = randomNumber(options.displayInterval.from + options.displayTime, options.displayInterval.to ? options.displayInterval.to + options.displayTime : 0);
                    setTimeout(showInterval, randomDelay * 1000);
                }
            };
    
            if (notifsCount > 0) {
                setTimeout(showInterval, initialDelay * 1000);
            }
    
            var showNotification = function(index) {
                if (audio) {
                    audio.play();
                }
                self.find('.woo-notify-single.velocity-animating').velocity("stop").velocity(options.exitAnim, { duration: options.animSpeed });
                self.find('.woo-notify-single').eq(index).show();
                self.find('.woo-notify-single').eq(index).velocity(options.entryAnim, { duration: options.animSpeed }).velocity(options.exitAnim, { duration: options.animSpeed, delay: options.displayTime * 1000 });
            }
    
            if (options.criteria === 'live-orders') {
                setInterval(function() {
                    $.post(fommerce.ajaxurl, {
                        action: 'fommerce_live_orders',
                        addon: 'notifications',
                        id: options.id
                    }, function(response) {
                        self.find('.woo-container').append(response.html.join());
                        if (response.count > 0) {
                            setTimeout(showInterval, 0);
                        }
                    }, 'json');
                }, 60 * 1000);
            }
    
            self.find('.woo-notify-close').on('click', function() {
                $(this).closest('.woo-notify-single').velocity('stop').velocity(options.exitAnim, { duration: options.animSpeed });
            });

        });

        function randomNumber(min, max) {
            min = Math.ceil(min);
            max = (!max || max == 0) ? min : Math.floor(max);
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

    }

    $.fn.fmcFeed = function(){
        var self = $(this);
        var options = self.data('options');

        var sliderOpts = {
            arrows: false,
            dots: false,
            infinite: true,
            vertical: true,
            verticalSwiping: true,
            infinite: options.loop,
            verticalReverse: (options.direction == 'down') ? true : false,
            slidesToShow: parseInt(options.slidesToShow),
            slidesToScroll: parseInt(options.slidesToScroll),
            autoplay: options.autoplay,
            autoplaySpeed: parseFloat(options.interval) * 1000,
            cssEase: 'cubic-bezier(0.785, 0.135, 0.15, 0.86)'
        };

        depp.require('fommerce-slick', function() {

            self.slick(sliderOpts);

            $(window).on('resize orientationchange', function() {
                self.slick('refresh');
            });

            if (options.criteria === 'live-orders') {
                setInterval(function() {
                    $.post(fommerce.ajaxurl, {
                        action: 'fommerce_live_orders',
                        addon: 'feeds',
                        id: options.id
                    }, function(response) {
                        if (response.count > 0) {
                            response.html.forEach(function(feed) {
                                self.slick('slickAdd', feed);
                            });
                        }
                    }, 'json');
                }, 60 * 1000);
            }

        });

    }

    $.fn.fmcTrigger = function() {
        var self = $(this);
        var id = self.attr('data-fomo-id');
        var addon = self.attr('data-fomo-addon');

        var container = $('.fommerce-notifs-' + id).eq(0);

        if (container.length) {
            depp.require('fommerce-velocity', function() {

                var options = container.data('options');

                if (container.find('.fommerce-audio').length) {
                    var audio = container.find(".fommerce-audio")[0];
                }

                self.on('click', function(e) {
                    e.preventDefault();
                    if (audio) {
                        audio.play();
                    }
                    container.find('.woo-notify-single.velocity-animating').velocity("stop").velocity(options.exitAnim, { duration: options.animSpeed });
                    container.find('.woo-notify-single').eq(0).show();
                    container.find('.woo-notify-single').eq(0).velocity(options.entryAnim, { duration: options.animSpeed }).velocity(options.exitAnim, { duration: options.animSpeed, delay: options.displayTime * 1000 });
                });
                
            });
        }
        
    }

    $('.fommerce-notifs').each(function() {
        $(this).fmcNotification();
    });

    $('.fomo-feeds').each(function() {
        $(this).fmcFeed();
    });
    $('.fommerce-trigger').each(function() {
        $(this).fmcTrigger();
    });

})(jQuery);