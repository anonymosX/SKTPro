<?php

if (!defined('ABSPATH')) {
    exit;
}

class FommerceShortcodes {

    public function notification_styles($notification) {

        $custom_css = ".fommerce-notifs-{$notification['id']} .woo-notify-single {
            max-width: {$notification['width']}px;
            font-size: {$notification['fontSize']}px;";
            if ($notification['font'] !== 'default') {
                $custom_css .= "font-family: {$notification['font']};";
            }
        $custom_css .= "}";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify {
            color: {$notification['textColor']};
            border-radius: {$notification['borderRadius']}px;";
            if (strpos($notification['background'], '/') !== false) {
                $custom_css .= "background-image: url({$notification['background']});";
            } else {
                $custom_css .= "background: {$notification['background']};";
            }
        $custom_css .= "}";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-top {
            top: {$notification['margin']['vertical']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-bottom {
            bottom: {$notification['margin']['vertical']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-left {
            left: {$notification['margin']['horizontal']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-right {
            right: {$notification['margin']['horizontal']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-content-avatar {
            background: {$notification['imageBackground']};
            margin: {$notification['imageMargin']}px;
            padding: {$notification['imagePadding']}px;
            border-radius: {$notification['borderRadius']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-content-avatar img {
            width: {$notification['imageSize']}px;
            height: {$notification['imageSize']}px;
        }";

        $custom_css .= ".fommerce-notifs-{$notification['id']} .woo-notify-content {
            padding-top: {$notification['padding']['top']}px;
            padding-right: {$notification['padding']['right']}px;
            padding-bottom: {$notification['padding']['bottom']}px;
            padding-left: {$notification['padding']['left']}px;
        }";

        return $custom_css;
        
    }

    public function feed_styles($id, $options) {
        $custom_css = "#fomo-feeds-{$id} {
        border-radius: {$options['borderRadius']}px;
        font-size: {$options['fontSize']}px;";
        if ($options['font'] !== 'default') {
            $custom_css .= "font-family: {$options['font']};";
        }
        if (strpos($options['widgetBackground'], 'http') !== false) {
            $custom_css .= "background-image: url({$options['widgetBackground']});";
        } else {
            $custom_css .= "background: {$options['widgetBackground']};";
        }
        $custom_css .= "}";

        $custom_css .= "#fomo-feeds-{$id} .woo-notify {
            color: {$options['textColor']};
            width: calc(100% - " . ($options['spacing'] * 2) . "px);
            margin: {$options['spacing']}px;
            border-radius: {$options['borderRadius']}px;
            box-shadow: {$options['shadow']['text']};";
            if (strpos($options['slideBackground'], 'http') !== false) {
                $custom_css .= "background-image: url({$options['slideBackground']});";
            } else {
                $custom_css .= "background: {$options['slideBackground']};";
            }
        $custom_css .= "}";

        $custom_css .= "#fomo-feeds-{$id} .woo-notify-content-avatar {
            background: {$options['imageBackground']};
            margin: {$options['imageMargin']}px;
            padding: {$options['imagePadding']}px;
            border-radius: {$options['borderRadius']}px;
        }";

        $custom_css .= "#fomo-feeds-{$id} .woo-notify-content-avatar img {
            width: {$options['imageSize']}px;
            height: {$options['imageSize']}px;
        }";

        $custom_css .= "#fomo-feeds-{$id} .woo-notify-content {
            padding-top: {$options['padding']['top']}px;
            padding-right: {$options['padding']['right']}px;
            padding-bottom: {$options['padding']['bottom']}px;
            padding-left: {$options['padding']['left']}px;
        }";

        return $custom_css;
    }

    public function notification_shortcode($id, $notification) {

        $mobile_detect = new Fommerce_Mobile_Detect();

        if (!$notification['active']) {
            return;
        }

        if (is_admin()) {
            return;
        }

        if ($notification['hideHomePage'] && is_home()) {
            return;
        }
        
        if ($notification['hideCheckoutPage'] && is_woocommerce_activated() && is_checkout()) {
            return;
        }

        if ($notification['hideCartPage'] && is_woocommerce_activated() && is_cart()) {
            return;
        }

        if (!$notification['enableDesktop'] && !$mobile_detect->isMobile()) {
            return;
        }

        if (!$notification['enableMobile'] && $mobile_detect->isMobile()) {
            return;
        }

        if ($notification['enableConditionalTags'] && !empty($notification['conditionalTags'])) {

            $condition = $notification['conditionalTags'];

            if (stristr($condition, "return") === false) {
                $condition = "return (" . $condition . ");";
            }

            if (!eval($condition)) {
                return;
            }
            
        }

        $products = new FommerceProducts($notification);
        $products = $products->get_products();

        $texts = $this->texts($notification, $products);
        $html = $this->notification_display($notification, $texts);

        $custom_css = $this->notification_styles($notification);

        wp_register_style('fommerce-custom', false);
        wp_enqueue_style('fommerce-custom');
        wp_add_inline_style('fommerce-custom', $custom_css);

        return $html;
    }

    public function feed_shortcode($id, $options) {

        $product_options = $options;
        $product_options['products']['orderTime'] = false;
        $product_options['products']['criteria'] = ($product_options['products']['criteria'] == 'live-orders') ? 'orders' : $product_options['products']['criteria'];

        $products = new FommerceProducts($product_options);
        $products = $products->get_products();

        $texts = $this->texts($options, $products);
        $html = $this->feed_display($options, $texts);

        $custom_css = $this->feed_styles($id, $options);

        wp_register_style('fommerce-custom', false);
        wp_enqueue_style('fommerce-custom');
        wp_add_inline_style('fommerce-custom', $custom_css);

        return $html;

    }

    public function texts($options, $products) {

        $texts = array();
        $fill_products = array();
        $limit = intval($options['products']['limit']);

        // Match number of products to limit
        if ($options['products']['virtual'] && $options['products']['criteria'] !== 'live-orders') {

            if (count($products) == 0) {
                $products[] = null;
            }
            
            while(count($fill_products) <= $limit) {
                $fill_products = array_merge($fill_products, $products);
            }
    
            $fill_products = array_slice($fill_products, 0, $limit);

        } else {
            $fill_products = $products;
        }

        for ($i = 0; $i < sizeof($fill_products); $i++) {
            $text = array(
                'message' => $this->parse_message($options, wp_kses_post($options['message']), $fill_products[$i]),
                'link' => $this->parse_message($options, wp_kses_post($options['link']), $fill_products[$i]),
                'image' => strpos($options['image'], 'fommerce-product.svg') !== false ? $fill_products[$i]['image'] : $options['image']
            );
            if (isset($options['heading'])) {
                $text['heading'] = $this->parse_message($options, wp_kses_post($options['heading']), $fill_products[$i]);
            }
            if (isset($options['corner'])) {
                $text['corner'] = $this->parse_message($options, wp_kses_post($options['corner']), $fill_products[$i]);
            }
            $texts[] = $text;
        }

        if ($options['products']['criteria'] !== 'live-orders' && $options['products']['randomize']) {
            shuffle($texts);
        }

        if (isset($options['displayCount'])) {
            $texts = array_slice($texts, 0, $options['displayCount']);
        }

        return $texts;

    }

    public function notification_display($notification, $texts) {

        $options = array(
            'id' => $notification['id'],
            'criteria' => $notification['products']['criteria'],
            'displayTime' => intval($notification['displayTime']),
            'displayDelay' => array(
                'from' => intval($notification['displayDelay']['from']),
                'to' => intval($notification['displayDelay']['to']),
            ),
            'displayInterval' => array(
                'from' => intval($notification['displayInterval']['from']),
                'to' => intval($notification['displayInterval']['to'])
            ),
            'loop' => ($notification['products']['criteria'] !== 'live-orders') ? $notification['loop'] : false,
            'randomize' => $notification['products']['randomize'],
            'entryAnim' => 'transition.' . $notification['entryAnim'],
            'exitAnim' => 'transition.' . $notification['exitAnim'],
            'animSpeed' => intval($notification['animSpeed']),
        );

        $out = '<div class="fommerce-notifs fommerce-notifs-' . $notification['id'] . '" data-index="0" data-options="' . htmlspecialchars(json_encode($options), ENT_QUOTES, 'UTF-8') . '">';
        $out .= '<div class="woo-container">';

        foreach ($texts as $text) {
            $out .= $this->notification_single($notification, $text);
        }

        $out .= '</div>';

        if (!empty($notification['sound'])) {
            $out .= '<audio class="fommerce-audio">';
            $out .= '<source src="' . $notification['sound'] . '">';
            $out .= '</audio>';
        }
        $out .= '</div>';

        return $out;

    }

    public function notification_single($notification, $text) {

        $out = '<div class="woo-notify-single ' . $notification['position'] . '">';

        $out .= ($text['link'] ? '<a href="' . $text['link'] . '"' : '<div') . ' class="woo-notify ' . $notification['theme'] . ' ' . $notification['headingPosition'] . '">';

        if (!empty($notification['heading'])) {
            $out .= '<div class="woo-notify-row woo-notify-title">';
            $out .= '<div>' . $text['heading'] . '</div>';
            if ($notification['corner'] !== '{x}') {
                $out .= '<div class="woo-notify-content-corner">' . $text['corner'] . '</div>';
            }
            $out .= '</div>';
        }
    
        $out .= '<div class="woo-notify-row woo-notify-body">';

        if ($notification['image'] !== 'fommerce-no') {
            $out .= '<div class="woo-notify-content-avatar ' . $notification['imagePosition'] . '">';
            $out .= '<img src="' . $text['image'] . '" alt="">';
            $out .= '</div>';
        }

        $out .= '<div class="woo-notify-content">';
        $out .= '<div class="woo-notify-content-text">' . $text['message'] . '</div>';
        if (empty($notification['heading']) && !empty($notification['corner']) && $notification['corner'] !== '{x}') {
            $out .= '<div class="woo-notify-content-corner">' . str_replace(array('<p>', '</p>'), '', $text['corner']) . '</div>';
        }
        $out .= '</div>';

        $out .= '</div>';
        $out .= $text['link'] ? '</a>' : '</div>';

        if ($notification['corner'] === '{x}') {
            $out .= $text['corner'];
        }

        $out .= '</div>';

        return $out;

    }

    public function feed_display($options, $texts) {
        $args = array(
            'id' => $options['id'],
            'criteria' => $options['products']['criteria'],
            'loop' => $options['loop'],
            'randomize' => $options['products']['randomize'],
            'direction' => $options['direction'],
            'slidesToShow' => min($options['slidesToShow'], $options['products']['limit'] - 1),
            'slidesToScroll' => $options['slidesToScroll'],
            'autoplay' => $options['autoplay'],
            'interval' => $options['interval'],
            'loop' => $options['loop'],
        );

        $out = '<div class="fomo-feeds" id="fomo-feeds-' . $options['id'] . '" data-options="' . htmlspecialchars(json_encode($args), ENT_QUOTES, 'UTF-8') . '">';

        foreach ($texts as $text) {
            $out .= $this->feed_single($options, $text);
        }

        $out .= '</div>';

        return $out;

    }

    public function feed_single($options, $text) {

        $out = ($text['link'] ? '<a href="' . $text['link'] . '"' : '<div') . ' class="fomo-feed-slide">';
        $out .= '<div class="woo-notify ' . $options['theme'] . '">';
        $out .= '<div class="woo-notify-row woo-notify-body">';
        $out .= '<div class="woo-notify-content-avatar ' . $options['imagePosition'] . '">';
        $out .= '<img src="' . $options['image'] . '" alt="">';
        $out .= '</div>';
        $out .= '<div class="woo-notify-content">';
        $out .= '<div class="woo-notify-content-text">' . $text['message'] . '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= $text['link'] ? '</a>' : '</div>';

        return $out;

    }

    public function parse_message($options, $message, $product) {

        $values = array();
        preg_match_all('/{(.*?)}/', $message, $matches);
        $criteria = $options['products']['criteria'];

        foreach ($matches[1] as $match) {

            $values[$match] = false;
            
            switch ($match) {

                case 'firstname':
                case 'lastname':

                    if ($product && $criteria === 'orders') {
                        $values[$match] = $product[$match];
                    } else {
                        $strings = explode("\n", $options['placeholders'][$match]['list']);
                        $values[$match] = (count($strings) > 0) ? $strings[array_rand($strings)] : false;
                    }

                    break;

                case 'city':
                case 'country':
                    
                    if ($options['placeholders'][$match]['autodetect']) {

                        if (function_exists('geoip_detect2_get_info_from_current_ip')) {
                            $geo = geoip_detect2_get_info_from_current_ip();
                            $values[$match] = $geo->{$match}->name;
                        }
                        
                    } else if ($product && $criteria === 'orders') {
                        $values[$match] = $product[$match];
                    } else {
                        $strings = explode("\n", $options['placeholders'][$match]['list']);
                        $values[$match] = (count($strings) > 0) ? $strings[array_rand($strings)] : false;
                    }

                    break;

                case 'state':
                    
                    if ($product && $criteria === 'orders') {
                        $values[$match] = $product[$match];
                    } else {
                        $strings = explode("\n", $options['placeholders'][$match]['list']);
                        $values[$match] = (count($strings) > 0) ? $strings[array_rand($strings)] : false;
                    }

                    break;

                case 'productname':

                    $values[$match] = $product ? $product['title'] : $match;

                    break;

                case 'productlink':

                    $values[$match] = $product ? $product['url'] : $match;

                    break;

                case 'productnamelink':

                    $values[$match] = $product ? '<a href="' . $product['url'] . '">' . $product['title'] . '</a>' : $match;

                    break;

                case 'price':

                    $values[$match] = $product ? $product[$match] : $match;

                    break;

                case 'date':

                    $timestamp = false;
                    $opts = $options['placeholders'][$match];

                    if ($product && $criteria === 'orders') {
                        $timestamp = $product['date']->getTimestamp();
                    } else if (!empty($opts['random'])) {
                        $timestamp = strtotime("-" . intval($opts['random']) . " " . $opts['randomUnit']);
                        $timestamp = rand($timestamp, time());
                    }

                    if ($timestamp) {
                        $format = empty($opts['custom']) ? array($opts['date'], $opts['time']) : array($opts['custom']);
                        $values[$match] = date(implode(' ', $format), $timestamp);
                    } else {
                        $values[$match] = $match;
                    }

                    break;

                case 'timeago':
                    
                    $timestamp = false;
                    $opts = $options['placeholders'][$match];

                    if ($product && $criteria === 'orders') {
                        $timestamp = $product['date']->getTimestamp();
                    } else if (!empty($opts['random'])) {
                        $timestamp = strtotime("-" . intval($opts['random']) . " " . $opts['randomUnit']);
                        $timestamp = rand($timestamp, time());
                    }

                    if ($timestamp) {
                        $values[$match] = $this->time_ago($timestamp, $opts['prefix'], $opts['suffix']);
                    } else {
                        $values[$match] = $match;
                    }

                    break;

                case 'rating':

                    $values[$match] = $product ? number_format($product['rating'], 1) : $match;

                    break;

                case 'starrating':

                    if ($product) {
                        $opts = $options['placeholders'][$match];

                        $out = '';
                        $rating = floatval($product['rating']);
                        $rating = ceil($rating * 2) / 2;
                
                        $star = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="isolation:isolate" viewBox="615.667 324.342 410.58 391.394" width="32" height="32">';
                        $star .= '<defs>';
                        $star .= '<clipPath id="_clipPath_cd5KdJGGjCN47Jvb0oFb3mjwR2F40sxv">';
                        $star .= '<rect x="615.667" y="324.342" width="410.58" height="391.394"/>';
                        $star .= '</clipPath>';
                        $star .= '</defs>';
                        $star .= '<g clip-path="url(#_clipPath_cd5KdJGGjCN47Jvb0oFb3mjwR2F40sxv)">';
                        $star .= '<path d=" M 821.246 324.342 C 819.597 324.342 817.949 325.615 816.692 328.162 L 760.733 441.546 C 758.219 446.64 751.615 451.438 745.994 452.255 L 620.867 470.437 C 615.246 471.254 613.985 475.136 618.052 479.101 L 708.595 567.358 C 712.662 571.323 715.185 579.087 714.225 584.685 L 692.85 709.306 C 691.89 714.905 695.192 717.304 700.22 714.661 L 812.137 655.823 C 814.651 654.501 817.949 653.84 821.246 653.84 L 821.246 324.342 Z " fill-rule="evenodd" fill="{colorleft}"/>';
                        $star .= '<path d=" M 820.667 324.342 C 822.316 324.342 823.965 325.615 825.221 328.162 L 881.18 441.546 C 883.694 446.64 890.298 451.438 895.919 452.255 L 1021.046 470.437 C 1026.667 471.254 1027.928 475.136 1023.861 479.101 L 933.318 567.358 C 929.251 571.323 926.728 579.087 927.688 584.685 L 949.063 709.306 C 950.023 714.905 946.721 717.304 941.693 714.661 L 829.776 655.823 C 827.262 654.501 823.964 653.84 820.667 653.84 L 820.667 324.342 Z " fill-rule="evenodd" fill="{colorright}"/>';
                        $star .= '</g>';
                        $star .= '</svg>';
                
                        for($x = 1; $x <= 5; $x++) {
                            $colorleft = ($x <= $rating || ($x - $rating) == .5) ? $opts['color'] : 'rgb(235,235,235)';
                            $colorright = ($x > $rating) ? 'rgb(235,235,235)' : $opts['color'];
                            $out .= str_replace(array('{colorleft}', '{colorright}'), array($colorleft, $colorright), $star);
                        }

                        $values[$match] = '<span class="woo-notify-stars">' . $out . '</span>';
                    } else {
                        $values[$match] = $match;
                    }

                    break;

                case 'randomnumber':

                    $opts = $options['placeholders'][$match];
                    $values[$match] = number_format_i18n(rand($opts['min'], $opts['max']), $opts['decimals']);

                    break;

                case 'x':

                    $out = '<div class="woo-notify-close">';
                    $out .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x">';
                    $out .= '<line x1="18" y1="6" x2="6" y2="18"></line>';
                    $out .= '<line x1="6" y1="6" x2="18" y2="18"></line>';
                    $out .= '</svg>';
                    $out .= '</div>';

                    $values[$match] = $out;

                    break;

                default:
                    $values[$match] = false;
            }

        }

        foreach ($values as $key => $value) {
            $value = ($value) ? $value : '{' . $key . '}';
            $message = str_replace('{' . $key . '}', $value, $message);
        }

        $message = empty($options['link']) ? $message : preg_replace('#<a.*?>([^>]*)</a>#i', '$1', $message); 
        return $message;

    }

    public function time_ago($time, $prefix = '', $suffix = '') {
        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array("60","60","24","7","4.35","12","10");

        $now = time();

        $difference = $now - $time;

        for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
            $difference /= $lengths[$j];
        }

        $difference = round($difference);

        if($difference != 1) {
            $periods[$j].= "s";
        }

        $timeago = array($prefix, $difference, $periods[$j], $suffix);

        return implode(' ', $timeago);
    }

}