<?php

if (!defined('ABSPATH')) {
    exit;
}

include_once ABSPATH . 'wp-admin/includes/plugin.php';

/**
 * Check if WooCommerce is activated
 */
if (!function_exists( 'is_woocommerce_activated')) {
	function is_woocommerce_activated() {
		if (class_exists('woocommerce')) { return true; } else { return false; }
	}
}

require_once FOMMERCE_PATH . 'includes/mobile_detect.php';
require_once FOMMERCE_PATH . 'includes/data.php';
require_once FOMMERCE_PATH . 'includes/admin.php';
require_once FOMMERCE_PATH . 'includes/products.php';
require_once FOMMERCE_PATH . 'includes/shortcodes.php';
require_once FOMMERCE_PATH . 'includes/updater.php';

?>