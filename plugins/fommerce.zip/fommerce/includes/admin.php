<?php

if (!defined('ABSPATH')) {
	exit;
}

class FommerceAdmin {

    public function __construct($data) {

        $this->data = $data;

        $this->addons = array(
            'notifications' => array(
                'short' => 'notifications',
                'title' => 'Notifications'
            ),
            'sales-feed' => array(
                'short' => 'feeds',
                'title' => 'Sales Feed'
            ),
            'settings' => array(
                'short' => 'config',
                'title' => 'Settings'
            )
        );

        $default_addon = ($this->data->options['config']['license'] === 'regular' || $this->data->options['config']['license'] === 'extended') ? 'notifications' : 'settings';
        $this->addon = (isset($_REQUEST['addon']) && array_key_exists($_REQUEST['addon'], $this->addons)) ? sanitize_key($_REQUEST['addon']) : $default_addon;

        add_action('admin_menu', array($this, 'menu_page'));
        add_action('admin_enqueue_scripts', array( $this, 'admin_scripts' ), 99999);
        add_action('wp_ajax_fommerce_save', array($this, 'save_addon'));
        add_action('wp_ajax_fommerce_search', array($this, 'search'));
        add_action('wp_ajax_fommerce_search_cat', array($this, 'search_categories'));
    }

    public function admin_scripts() {

        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';

        if ($page == 'fommerce') {

            // styles
            wp_enqueue_media();
            wp_enqueue_style('fommerce-admin-vendor', FOMMERCE_URL . 'assets/admin/css/vendor.min.css', array(), FOMMERCE_VERSION);
            wp_enqueue_style('fommerce-admin', FOMMERCE_URL . 'assets/admin/css/style.css', array(), FOMMERCE_VERSION);

            // scripts
            wp_enqueue_script('fommerce-admin-vendor', FOMMERCE_URL . 'assets/admin/js/vendor.min.js', array('jquery'), FOMMERCE_VERSION);
            wp_register_script('fommerce-admin', FOMMERCE_URL . 'assets/admin/js/script.js', array('jquery'), FOMMERCE_VERSION);

            $args = array(
                'url' => FOMMERCE_URL,
                'domain' => home_url(),
                'ajaxurl' => admin_url('admin-ajax.php'),
                'addon' => $this->addons[$this->addon]['short'],
                'defaults' => $this->data->defaults,
                'options' => array(
                    'notifications' => array_map(function($notification) { return array_replace_recursive($this->data->defaults['notifications'], $notification); }, $this->data->options['notifications']),
                    'feeds' => array_map(function($feed) { return array_replace_recursive($this->data->defaults['feeds'], $feed); }, $this->data->options['feeds']),
                    'config' => array_replace_recursive($this->data->defaults['config'], $this->data->options['config'])
                )
            );

            wp_localize_script('fommerce-admin', 'fommerce', wp_parse_args($args));
            wp_enqueue_script('fommerce-admin');
        }
    }

    public function menu_page() {
        add_menu_page(esc_html__('Fommerce', 'fommerce'), esc_html__('Fommerce', 'fommerce' ), 'manage_options', 'fommerce', array($this, 'fommerce_editor'), 'data:image/svg+xml;base64,'.base64_encode('<svg width="100%" height="100%" viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" xmlns:serif="http://www.serif.com/" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;"><g transform="matrix(0.264441,0,0,0.264441,-56.4472,-32.9375)"><g transform="matrix(1.12975,0,0,1.49558,-260.134,-176.058)"><path d="M728.191,211.214L471.496,211.214C456.83,211.214 444.941,220.195 444.941,231.273C444.941,250.968 444.941,278.078 444.941,278.078L701.636,278.078C716.302,278.078 728.191,269.097 728.191,258.018C728.191,238.323 728.191,211.214 728.191,211.214Z" style="fill:rgb(150,150,150);"/></g><g transform="matrix(0.776701,0,0,1.49558,-103.05,-52.4664)"><path d="M728.191,211.214L444.941,211.214L444.941,278.078L689.566,278.078C710.898,278.078 728.191,269.097 728.191,258.018C728.191,238.323 728.191,211.214 728.191,211.214Z" style="fill:rgb(150,150,150);"/></g><g transform="matrix(0.423655,0,0,1.49558,54.0353,71.5533)"><path d="M728.191,211.214L444.941,211.214L444.941,278.078L657.378,278.078C696.487,278.078 728.191,269.097 728.191,258.018C728.191,238.323 728.191,211.214 728.191,211.214Z" style="fill:rgb(150,150,150);"/></g></g></svg>'), 58);
    }

    public function fommerce_editor() {
        require_once(FOMMERCE_PATH . 'backend/layout.php');
    }

    public function save_addon() {
        
        if (!isset($_POST['nonce']) || !isset($_POST['data'])) {
			wp_send_json_error();
        }
        
		if (!wp_verify_nonce($_POST['nonce'], 'fommerce_editor')) {
			wp_send_json_error();
        }
        
		if (!current_user_can('manage_options')) {
			wp_send_json_error();
        }

        $json = array();
        $addon = sanitize_key($_POST['addon']);
        $raw_data = json_decode(wp_unslash($_POST['data']), true);

        if ($addon === 'config') {
            $json = $this->get_sanitized_data($raw_data, $addon);
        } else {
            foreach ($raw_data as $data) {
                $json[] = $this->get_sanitized_data($data, $addon);
            }
        }
        
        update_option('fommerce_' . $addon, $json);
        wp_send_json_success(array('data' => $json));
    }

    public function search($x = '', $post_types = array('product')) {
        
        $products = array();

        $keyword = filter_input(INPUT_POST, 'keyword', FILTER_SANITIZE_STRING);

		if (!empty($keyword)) {

            $results = new WP_Query(
                array(
                    'post_status'    => 'publish',
                    'post_type'      => $post_types,
                    'posts_per_page' => 10,
                    's'              => $keyword
                )
            );

            if ($results->have_posts()) {
                while ($results->have_posts()) {
                    $results->the_post();

                    $product = wc_get_product(get_the_ID());
                    $currency = get_woocommerce_currency_symbol();

                    $products[] = array(
                        'id' => $product->get_id(),
                        'name' => $product->get_name(),
                        'image' => wp_get_attachment_url($product->get_image_id()),
                        'price' => $currency . $product->get_price()
                    );
                }
            }
			
        }
        
		wp_send_json($products);
		die;
    }
    
    public function search_categories($args = array()) {

        $categories = array();

        $keyword = filter_input(INPUT_POST, 'keyword', FILTER_SANITIZE_STRING);

        $args = array(
            'orderby' => 'name',
            'order' => 'asc',
            'hide_empty' => false,
            'number' => 50,
            'search' => $keyword
        );

        $terms = get_terms('product_cat', $args);

        if (!empty($terms)) {
            foreach ($terms as $term) {
                $categories[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                );
            }
        }

        wp_send_json($categories);
        die;

    }

    public function sanitize_color($color) {
        if (empty($color) || is_array($color))
            return 'rgba(0,0,0,0)';
    
        // If string does not start with 'rgba', then treat as hex
        // sanitize the hex color and finally convert hex to rgba
        if (false === strpos($color, 'rgba')) {
            return sanitize_hex_color($color);
        }
    
        // By now we know the string is formatted as an rgba color so we need to further sanitize it.
        $color = str_replace(' ', '', $color);
        sscanf($color, 'rgba(%d,%d,%d,%f)', $red, $green, $blue, $alpha);
        return 'rgba('.$red.','.$green.','.$blue.','.$alpha.')';
    }

    public function sanitize_html_classes($classes, $sep = " "){
        $return = array();
 
        if(!is_array($classes)) {
            $classes = explode($sep, $classes);
        }
 
        if(!empty($classes)){
            foreach($classes as $class){
                $return[] = sanitize_html_class($class);
            }
        }
 
        return implode(" ", $return);
    }

    public static function array_diff_recursive($array1, $array2) {
        $result = array();

        foreach ($array1 as $key => $value) {
            if (!is_array($array2) || !array_key_exists($key, $array2)) {
                $result[$key] = $value;
                continue;
            }

            if (is_array($value)) {
                $recursiveArrayDiff = static::array_diff_recursive($value, $array2[$key]);

                if (count($recursiveArrayDiff)) {
                    $result[$key] = $recursiveArrayDiff;
                }

                continue;
            }

            if ($value != $array2[$key]) {
                $result[$key] = $value;
            }
        }

        return $result;
    }

    public function get_sanitized_data($data, $addon) {

        $sanitized_data = array();

        if ($addon === 'notifications') {

            $array = array(
                'id' => intval($data['id']),
                'active' => boolval($data['active']),
                'title' => sanitize_text_field($data['title']),
                'enableDesktop' => boolval($data['enableDesktop']),
                'enableMobile' => boolval($data['enableMobile']),
                'enableConditionalTags' => boolval($data['enableConditionalTags']),
                'conditionalTags' => sanitize_text_field($data['condionalTags']),
                'hideHomePage' => boolval($data['hideHomePage']),
                'hideCheckoutPage' => boolval($data['hideCheckoutPage']),
                'hideCartPage' => boolval($data['hideCartPage']),
                'message' => stripslashes(wp_filter_post_kses($data['message'])),
                'corner' => stripslashes(wp_filter_post_kses($data['corner'])),
                'link' => stripslashes(wp_filter_post_kses($data['link'])),
                'heading' => stripslashes(wp_filter_post_kses($data['heading'])),
                'theme' => $this->sanitize_html_classes($data['theme']),
                'position' => $this->sanitize_html_classes($data['position']),
                'imagePosition' => $this->sanitize_html_classes($data['imagePosition']),
                'headingPosition' => $this->sanitize_html_classes($data['headingPosition']),
                'textColor' => $this->sanitize_color($data['textColor']),
                'background' => $this->sanitize_color($data['background']),
                'imageBackground' => $this->sanitize_color($data['imageBackground']),
                'width' => intval($data['width']),
                'borderRadius' => intval($data['borderRadius']),
                'margin' => array('horizontal' => intval($data['margin']['horizontal']), 'vertical' => intval($data['margin']['vertical'])),
                'padding' => array('top' => intval($data['padding']['top']), 'right' => intval($data['padding']['right']), 'bottom' => intval($data['padding']['bottom']), 'left' => intval($data['padding']['left'])),
                'font' => sanitize_text_field($data['font']),
                'fontSize' => intval($data['fontSize']),
                'imageSize' => intval($data['imageSize']),
                'imageMargin' => intval($data['imageMargin']),
                'imagePadding' => intval($data['imagePadding']),
                'entryAnim' => sanitize_text_field($data['entryAnim']),
                'exitAnim' => sanitize_text_field($data['exitAnim']),
                'animSpeed' => intval($data['animSpeed']),
                'image' => esc_url($data['image']),
                'displayDelay' => array(
                    'from' => intval($data['displayDelay']['from']),
                    'to' => intval($data['displayDelay']['to'])
                ),
                'displayTime' => intval($data['displayTime']),
                'displayInterval' => array(
                    'from' => intval($data['displayInterval']['from']),
                    'to' => intval($data['displayInterval']['to'])
                ),
                'displayCount' => intval($data['displayCount']),
                'loop' => boolval($data['loop']),
                'sound' => sanitize_text_field($data['sound'])
            );

            $sanitized_data = array_merge($sanitized_data, $array);

        }

        if ($addon === 'feeds') {

            $array = array(
                'id' => intval($data['id']),
                'active' => boolval($data['active']),
                'title' => sanitize_text_field($data['title']),
                'slidesToShow' => intval($data['slidesToShow']),
                'slidesToScroll' => intval($data['slidesToScroll']),
                'interval' => intval($data['interval']),
                'direction' => sanitize_key($data['direction']),
                'autoplay' => boolval($data['autoplay']),
                'loop' => boolval($data['loop']),
                'message' => stripslashes(wp_filter_post_kses($data['message'])),
                'link' => stripslashes(wp_filter_post_kses($data['link'])),
                'image' => esc_url($data['image']),
                'theme' => $this->sanitize_html_classes($data['theme']),
                'textColor' => $this->sanitize_color($data['textColor']),
                'imageBackground' => $this->sanitize_color($data['imageBackground']),
                'slideBackground' => $this->sanitize_color($data['slideBackground']),
                'widgetBackground' => $this->sanitize_color($data['widgetBackground']),
                'border' => array('top' => intval($data['border']['top']), 'right' => intval($data['border']['right']), 'bottom' => intval($data['border']['bottom']), 'left' => intval($data['border']['left'])),
                'borderColor' => $this->sanitize_color($data['borderColor']),
                'borderRadius' => intval($data['borderRadius']),
                'shadow' => array(
                    'enabled' => boolval($data['shadow']['enabled']),
                    'color' => $this->sanitize_color($data['shadow']['color']),
                    'blur' => intval($data['shadow']['blur']),
                    'spread' => intval($data['shadow']['spread']),
                    'horizontal' => intval($data['shadow']['horizontal']),
                    'vertical' => intval($data['shadow']['vertical']),
                    'text' => sanitize_text_field($data['shadow']['text'])
                ),
                'spacing' => intval($data['spacing']),
                'padding' => array('top' => intval($data['padding']['top']), 'right' => intval($data['padding']['right']), 'bottom' => intval($data['padding']['bottom']), 'left' => intval($data['padding']['left'])),
                'font' => sanitize_text_field($data['font']),
                'fontSize' => intval($data['fontSize']),
                'imagePosition' => $this->sanitize_html_classes($data['imagePosition']),
                'imageSize' => intval($data['imageSize']),
                'imageMargin' => intval($data['imageMargin']),
                'imagePadding' => intval($data['imagePadding'])
            );

            $sanitized_data = array_merge($sanitized_data, $array);

        }

        if ($addon === 'config') {

            $array = array(
                'license' => sanitize_key($data['license']),
                'licenseKey' => sanitize_text_field($data['licenseKey'])
            );

            return $array;
        }

        if ($addon === 'notifications' || $addon === 'feeds') {

            $array = array(
                'placeholder' => '',
                'placeholders' => array(
                    'firstname' => array(
                        'list' => sanitize_textarea_field($data['placeholders']['firstname']['list'])
                    ),
                    'lastname' => array(
                        'list' => sanitize_textarea_field($data['placeholders']['lastname']['list'])
                    ),
                    'city' => array(
                        'autodetect' => boolval($data['placeholders']['city']['autodeetect']),
                        'list' => sanitize_textarea_field($data['placeholders']['city']['list'])
                    ),
                    'state' => array(
                        'list' => sanitize_textarea_field($data['placeholders']['state']['list'])
                    ),
                    'country' => array(
                        'autodetect' => boolval($data['placeholders']['country']['autodetect']),
                        'list' => sanitize_textarea_field($data['placeholders']['country']['list'])
                    ),
                    'date' => array(
                        'date' => sanitize_text_field($data['placeholders']['date']['date']),
                        'time' => sanitize_text_field($data['placeholders']['date']['time']),
                        'custom' => sanitize_text_field($data['placeholders']['date']['custom']),
                        'random' => intval($data['placeholders']['date']['random']),
                        'randomUnit' => sanitize_key($data['placeholders']['date']['randomUnit'])
                    ),
                    'timeago' => array(
                        'prefix' => sanitize_text_field($data['placeholders']['timeago']['prefix']),
                        'suffix' => sanitize_text_field($data['placeholders']['timeago']['suffix']),
                        'random' => intval($data['placeholders']['timeago']['random']),
                        'randomUnit' => sanitize_key($data['placeholders']['timeago']['randomUnit'])
                    ),
                    'starrating' => array(
                        'color' => $this->sanitize_color($data['placeholders']['starrating']['color'])
                    ),
                    'randomnumber' => array(
                        'min' => intval($data['placeholders']['randomnumber']['min']),
                        'max' => intval($data['placeholders']['randomnumber']['max']),
                        'decimals' => intval($data['placeholders']['randomnumber']['decimals'])
                    ),
                ),
                'products' => array(
                    'criteria' => sanitize_key($data['products']['criteria']),
                    'limit' => intval($data['products']['limit']),
                    'orderStatus' => isset($data['products']['orderStatus']) ? $data['products']['orderStatus'] : array(),
                    'orderTime' => intval($data['products']['orderTime']),
                    'orderTimeUnit' => sanitize_key($data['products']['orderTimeUnit']),
                    'categories' => isset($data['products']['categories']) ? $data['products']['categories'] : array(),
                    'selectProducts' => isset($data['products']['selectProducts']) ? $data['products']['selectProducts'] : array(),
                    'excludeProducts' => isset($data['products']['excludeProducts']) ? $data['products']['excludeProducts'] : array(),
                    'excludeOutOfStock' => boolval($data['products']['excludeOutOfStock']),
                    'randomize' => boolval($data['products']['randomize']),
                    'virtual' => boolval($data['products']['virtual'])
                )
            );

            $sanitized_data = array_merge($sanitized_data, $array);

        }

        $sanitized_data = $this->array_diff_recursive($sanitized_data, $this->data->defaults[$addon]);

        return $sanitized_data;

    }

}