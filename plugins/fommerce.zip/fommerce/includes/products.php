<?php

if (!defined('ABSPATH')) {
    exit;
}

class FommerceProducts {

    public function __construct($options) {

        $this->products = array();
        $this->options = $options;

        $this->order = array(
            'statuses' => array_map(function($status) { return $status['id']; }, $this->options['products']['orderStatus']),
            'time' => $this->options['products']['orderTime'],
            'timeunit' => $this->options['products']['orderTimeUnit']
        );

        $this->args = array();
        $this->limit = intval($this->options['products']['limit'] == 0) ? -1 : intval($this->options['products']['limit']);
        $this->categories = array_map(function($product) { return $product['id']; }, $this->options['products']['categories']);
        $this->select_products = array_map(function($product) { return $product['id']; }, $this->options['products']['selectProducts']);
        $this->exclude_products = array_map(function($product) { return $product['id']; }, $this->options['products']['excludeProducts']);

    }

    public function get_products() {

        switch ($this->options['products']['criteria']) {

            case 'no-products':
            case 'live-orders':

                return $this->products;

            case 'orders':

                $this->get_orders_with_products();

                return $this->products;

            case 'select-products':

                if ($this->select_products && count($this->select_products) > 0) {

                    $this->args = array(
                        'post_type' => array('product', 'product_variation'),
                        'post_status' => 'publish',
                        'post__in' => $this->select_products,
                        'orderby' => 'rand',
                    );
    
                    break;

                } else {

                    return $this->products;

                }

            case 'latest-products':
            
                $this->args = array(
                    'post_type' => 'product',
                    'post_status' => 'publish',
                    'posts_per_page' => $this->limit,
                    'orderby' => 'date',
                    'order' => 'DESC',
                    'post__not_in' => $this->exclude_products
                );

                break;

            case 'select-categories':

                if (is_array($this->categories) && count($this->categories) > 0) {

                    $categories = get_terms(
                        array(
                            'taxonomy' => 'product_cat',
                            'include' => $this->categories
                        )
                    );

                    $categories = array_map(function($term) { return $term->term_id; }, $categories);

                    if (count($categories) > 0) {

                        $this->args = array(
							'post_type'      => 'product',
							'post_status'    => 'publish',
							'posts_per_page' => $this->limit,
							'orderby'        => 'rand',
							'post__not_in'   => $this->exclude_products,
							'tax_query'      => array(
								array(
									'taxonomy'         => 'product_cat',
									'field'            => 'id',
									'terms'            => $categories,
									'include_children' => false,
									'operator'         => 'IN'
								),
							)
						);

                    }

                }

                break;

            case 'viewed-products':

                $viewed_products = !empty($_COOKIE['woocommerce_recently_viewed']) ? (array) explode('|', wp_unslash($_COOKIE['woocommerce_recently_viewed'])) : array();
                $viewed_products = array_reverse(array_filter(array_map('absint', $viewed_products)));

                $this->args = array(
                    'post_type' => 'product',
                    'post_status' => 'publish',
                    'post__in' => $viewed_products,
                    'posts_per_page' => $this->limit,
                    'orderby' => 'post__in',
                );

                break;
                
        }

        if (!isset($this->args['post_type'])) {
            return;
        }

        $this->args['no_found_rows'] = true;

        if ($this->options['products']['excludeOutOfStock']) {
            $this->args['meta_query'] = array(
                array(
                    'key'     => '_stock_status',
                    'value'   => 'instock',
                    'compare' => '='
                ),
            );
        }

        $the_query = new WP_Query($this->args);

        if ($the_query->have_posts()) {

            $currency = get_woocommerce_currency_symbol();

            while ($the_query->have_posts()) {
                $the_query->the_post();

                $product = wc_get_product(get_the_ID());

                $this->products[] = array(
                    'id' => $product->get_id(),
                    'order_id' => 0,
                    'title' => $product->get_name(),
                    'price' => $currency . $product->get_price(),
                    'url' => $product->get_permalink(),
                    'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
                    'rating' => $product->get_average_rating()
                );
            }
        }

        wp_reset_postdata();

        return $this->products;

    }

    public function get_orders_with_products() {

        $this->args = array(
            'post_type'      => 'shop_order',
            'post_status'    => $this->order['statuses'],
            'posts_per_page' => $this->limit,
            'orderby' => 'date',
            'order' => 'DESC'
        );

        if ($this->order['time']) {

            $time = strtotime("-" . $this->order['time'] . " " . $this->order['timeunit']);

            $this->args['date_query'] = array(
                array(
                    'after' => array(
                        'year' => date("Y", $time),
                        'month' => date("m", $time),
                        'day' => date("d", $time),
                        'hour' => date("H", $time),
                        'minute' => date("i", $time),
                        'second' => date("s", $time),
                    ),
                    'inclusive' => true,
                    'compare' => '<=',
                    'column' => 'post_date',
                    'relation' => 'AND'
                ),
            );

        }

        $the_query = new WP_Query($this->args);

        if ($the_query->have_posts()) {

            $currency = get_woocommerce_currency_symbol();

            while($the_query->have_posts()) {
                $the_query->the_post();

                $order = new WC_Order(get_the_ID());
                $items = $order->get_items();

                foreach ($items as $item) {

                    if (!isset($item['product_id'])) {
                        continue;
                    }

                    if (in_array($item['product_id'], $this->exclude_products)) {
                        continue;
                    }

                    if (!$order->has_billing_address()) {
                        continue;
                    }

                    $product = wc_get_product($item['product_id']);

                    if (empty($product)) {
                        continue;
                    }

                    if ($product->get_stock_status() !== 'instock' && $this->options['products']['excludeOutOfStock']) {
                        continue;
                    }

                    if ($product->get_status() != 'publish') {
                        continue;
                    }

                    if ($product->get_catalog_visibility() == 'hidden') {
                        continue;
                    }

                    $this->products[] = array(
                        'id' => $product->get_id(),
                        'order_id' => get_the_ID(),
                        'title' => $product->get_name(),
                        'price' => $currency . $product->get_price(),
                        'date' => $order->get_date_completed() ? $order->get_date_completed() : $order->get_date_created(),
                        'image' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
                        'rating' => $product->get_average_rating(),
                        'firstname' => $order->get_billing_first_name(),
                        'lastname' => $order->get_billing_last_name(),
                        'city' => $order->get_billing_city(),
                        'state' => $order->get_billing_state(),
                        'country' => $order->get_billing_country(),
                        'url' => $product->get_permalink(),
                    );

                }
            }
        }

        wp_reset_postdata();

    }

}