<?php
/*
    * Plugin Name: Fommerce - Fomo for WooCommerce
    * Plugin URI: https://fommerce.blocksera.com
    * Description: Add Fomo elements to your WooCommerce shop
    * Author: Blocksera
    * Author URI: https://blocksera.com
    * Version: 			1.1.0
    * Requires at least:   2.9.0
    * Tested up to:       5.4.0
    * WC tested up to: 3.8.1
    * License: 			GPL v3
    * License: GPL2+
    * Text Domain: fommerce
    * Domain Path: /languages/
*/

if (!defined('ABSPATH')) {
    exit;
}

define('FOMMERCE_VERSION', '1.1.0');
define('FOMMERCE_PATH', plugin_dir_path(__FILE__));
define('FOMMERCE_URL', plugin_dir_url(__FILE__));

require(FOMMERCE_PATH . 'includes/all.php');

class Fommerce {

    public function __construct() {

        // Initialize data
        $this->data = new FommerceData();
        $this->options = $this->data->options;

        // Update checker
        $this->updater = new Blocksera_Updater(__FILE__, 'fommerce', 'f2YRuPC9enQ7gFQWtwfF', $this->options['config']['licenseKey']);

        $admin = new FommerceAdmin($this->data);

        add_shortcode('fommerce', array($this, 'shortcode'));
        add_action('wp_footer', array($this, 'add_footer'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'frontend_assets'), 99999);
        add_action('wp_ajax_fommerce_license', array($this, 'check_license'));
        add_action('wp_ajax_fommerce_live_orders', array($this, 'live_orders'));
        add_action('wp_ajax_nopriv_fommerce_live_orders', array($this, 'live_orders'));
        add_action('template_redirect', array($this, 'track_product_view'));

        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

    }

    public function admin_notice_woocommerce_required() {
		$message = sprintf(
			esc_html__('%1$s requires %2$s to be installed and activated.', 'fommerce' ),
			'<strong>' . esc_html__('Fommerce', 'fommerce') . '</strong>',
			'<strong>' . esc_html__('WooCommerce', 'fommerce') . '</strong>'
		);
		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    public function admin_assets() {
        $page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';

        if ($page == 'fommerce') {
            wp_enqueue_style('fommerce-slick', FOMMERCE_URL . 'assets/public/css/slick.css', array(), FOMMERCE_VERSION);
            wp_enqueue_style('fommerce-slick-theme', FOMMERCE_URL . 'assets/public/css/slick-theme.css', array(), FOMMERCE_VERSION);
            wp_enqueue_style('fommerce', FOMMERCE_URL . 'assets/public/css/style.css', array(), FOMMERCE_VERSION);
        }
    }

    public function frontend_assets() {

        $fonts = array();

        foreach ($this->options['notifications'] as $notification) {
            if ($notification['font'] !== 'default') {
                $fonts[] = $notification['font'];
            }
        }

        foreach ($this->options['feeds'] as $feed) {
            if ($feed['font'] !== 'default') {
                $fonts[] = $feed['font'];
            }
        }

        if (count($fonts) > 0) {
            wp_enqueue_style('fommerce-notifs-fonts', 'https://fonts.googleapis.com/css?family=' . implode('|', str_replace(' ', '+', array_unique($fonts))));
        }

        if (count($this->options['feeds']) > 0) {
            wp_enqueue_style('fommerce-slick', FOMMERCE_URL . 'assets/public/css/slick.css', array(), FOMMERCE_VERSION);
            wp_enqueue_style('fommerce-slick-theme', FOMMERCE_URL . 'assets/public/css/slick-theme.css', array(), FOMMERCE_VERSION);
        }

        if (count($this->options['notifications']) > 0 || count($this->options['feeds']) > 0) {
            wp_enqueue_style('fommerce', FOMMERCE_URL . 'assets/public/css/style.css', array(), FOMMERCE_VERSION);
            wp_register_script('fommerce', FOMMERCE_URL . 'assets/public/js/script.js', array('jquery'), FOMMERCE_VERSION, true);

            $args = array(
                'url' => FOMMERCE_URL,
                'version' => FOMMERCE_VERSION,
                'ajaxurl' => admin_url('admin-ajax.php')
            );

            wp_localize_script('fommerce', 'fommerce', wp_parse_args($args));
            wp_enqueue_script('fommerce');
        }

    }

    public function activate() {
        
    }

    public function deactivate() {

    }

    public function check_license() {

        if (!current_user_can('manage_options')) {
			return;
        }

        $license_action = sanitize_key($_POST['license_action']);
        $this->options['config']['licenseKey'] = sanitize_key($_POST['code']);

        $response = array();

        $queryargs = array(
            'code' => $this->options['config']['licenseKey'],
            'remove' => ($license_action == 'deactivate') ? 'true' : 'false'
        );

        $update = $this->updater->request_info($queryargs);

        if ($update->license_error == 'limit_exceeded') {
            $response['message'] = __('You have already used this code on another site. Please deactivate license from the site or buy another license', 'fommerce');
        } else if ($update->license_error == 'site_removed') {
            $response['message'] = __('Your license has been removed from this site. It can now be used again. Please refresh this page', 'fommerce');
            $this->options['config']['licenseKey'] = '';
        } else if ($update->license == 'false') {
            $response['message'] = __('Your purchase code is not valid. Please try again.', 'fommerce');
        } else if ($update->license == 'regular' || $update->license == 'extended') {
            $response['message'] = __('Fommerce has been activated. Please refresh this page.', 'fommerce');
        } else {
            $response['message'] = __('Something went wrong. Please try again later.', 'fommerce');
        }

        $this->options['config']['license'] = $update->license;

        $response['license'] = $this->options['config']['license'];
        update_option('fommerce_config', $this->options['config']);
        wp_send_json($response);
    }

    public function track_product_view() {
        global $post;

        $track_product_view = false;

        if (!is_singular('product')) {
			return;
        }
        
        foreach ($this->options['notifications'] as $notification) {
            if ($notification['active'] && $notification['products']['criteria'] == 'viewed-products') {
                $track_product_view = true;
            }
        }

        foreach ($this->options['feeds'] as $feed) {
            if ($feed['active'] && $feed['products']['criteria'] == 'viewed-products') {
                $track_product_view = true;
            }
        }

        if ($track_product_view) {
    
            if (empty( $_COOKIE['woocommerce_recently_viewed'])) {
                $viewed_products = array();
            } else {
                $viewed_products = wp_parse_id_list((array) explode('|', wp_unslash($_COOKIE['woocommerce_recently_viewed'])));
            }
    
            // Unset if already in viewed products list.
            $keys = array_flip($viewed_products);
    
            if (isset($keys[$post->ID])) {
                unset($viewed_products[$keys[$post->ID]]);
            }
    
            $viewed_products[] = $post->ID;
    
            if (count($viewed_products) > 15) {
                array_shift($viewed_products);
            }
            // Store for session only.
            wc_setcookie('woocommerce_recently_viewed', implode('|', $viewed_products));

        }

    }

    public function live_orders() {

        $html = array();

        if ($_REQUEST['addon'] == 'notifications') {

            foreach ($this->options['notifications'] as $n) {
                if ($n['id'] == $_REQUEST['id']) {
                    $notification = $n;
                    break;
                }
            }

            $products = new FommerceProducts($notification);
            $products->order['time'] = 1;
            $products->order['timeunit'] = 'minutes';
            $products->get_orders_with_products();
            $products = $products->products;

            $shortcode = new FommerceShortcodes();
            $texts = $shortcode->texts($notification, $products);

            foreach ($texts as $text) {
                $html[] = $shortcode->notification_single($notification, $text);
            }
            
        } else if ($_REQUEST['addon'] == 'feeds') {

            foreach ($this->options['feeds'] as $f) {
                if ($f['id'] == $_REQUEST['id']) {
                    $feed = $f;
                    break;
                }
            }

            $products = new FommerceProducts($feed);
            $products->order['time'] = 1;
            $products->order['timeunit'] = 'minutes';
            $products->get_orders_with_products();
            $products = $products->products;

            $shortcode = new FommerceShortcodes();
            $texts = $shortcode->texts($feed, $products);

            foreach ($texts as $text) {
                $html[] = $shortcode->feed_single($feed, $text);
            }

        }

        wp_send_json(array('count' => sizeof($html), 'html' => $html));

    }

    public function shortcode($atts) {

        $atts = shortcode_atts(array(
            'id' => '',
            'addon' => 'feed'
        ), $atts, 'fommerce');

        if ($atts['addon'] == 'feed') {

            foreach ($this->options['feeds'] as $f) {
                if ($f['id'] == $atts['id']) {
                    $options = $f;
                    break;
                }
            }

            if (!isset($options)) {
                return;
            }

            $feed = new FommerceShortcodes();
            $options = array_replace_recursive($this->data->defaults['feeds'], $options);
            return $feed->feed_shortcode($options['id'], $options);

        }

        return;
        
    }

    public function add_footer() {

        $html = array();

        foreach ($this->options['notifications'] as $notification) {
            $shortcode = new FommerceShortcodes();
            $notification = array_replace_recursive($this->data->defaults['notifications'], $notification);
            $html[] = $shortcode->notification_shortcode($notification['id'], $notification);
        }

        echo implode("\n", $html);

    }

}

new Fommerce();