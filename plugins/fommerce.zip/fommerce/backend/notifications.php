<h1 class="wp-heading-inline mb-2">Notifications</h1>
<hr class="wp-header-end">

<template id="fommerce-notifications">

    <div class="template-content">

        <div class="live-preview live-preview-notifications">
            <div class="woo-container" v-show="isActive" v-bind:style="containerStyle">
                <div class="woo-notify-single" v-bind:class="notification.position" v-bind:style="singleNotifyStyle">
                    <div class="woo-notify" v-bind:class="[notification.theme, notification.headingPosition]" v-bind:style="notifyStyle">
                        <div class="woo-notify-row woo-notify-title" v-if="notification.heading.length > 0">
                            <div v-html="notification.heading"></div>
                            <div class="woo-notify-content-corner" v-html="notification.corner"></div>
                        </div>
                        <div class="woo-notify-row woo-notify-body">
                            <div class="woo-notify-content-avatar" v-bind:class="notification.imagePosition" v-bind:style="imageContainerStyle">
                                <img v-bind:src="notification.image" alt="" v-if="notification.image.indexOf('fommerce-no') == -1" v-bind:style="imageStyle">
                            </div>
                            <div class="woo-notify-content" v-bind:style="textStyle">
                                <div class="woo-notify-content-text" v-html="notification.message"></div>
                                <div class="woo-notify-content-corner" v-html="notification.corner" v-if="notification.heading.length == 0"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel mt-2" v-bind:class="{ active: isActive }">

            <div class="panel-header">
                <div class="panel-title" v-on:dblclick="$parent.toggle(notification.id)">
                    <label class="form-switch d-inline-block">
                        <input type="checkbox" v-model="notification.active">
                        <i class="form-icon"></i> {{ notification.title }}
                    </label>
                    <div>
                        <div v-on:click="$parent.toggle(notification.id)" class="panel-btn"><i class="ft ft-minimize" v-if="isActive"></i><i class="ft ft-maximize" v-else></i></div>
                        <div v-on:click="$parent.remove(notification.id)" class="panel-btn"><i class="ft ft-trash"></i></div>
                    </div>
                </div>
            </div>

            <ul class="tab tab-block" v-show="isActive">
                <li class="tab-item" v-bind:class="{ active: (tab == 'general') }" v-on:click="selectTab('general')"><a href="#general-tab">General</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'messages') }" v-on:click="selectTab('messages')"><a href="#messages-tab">Messages</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'products') }" v-on:click="selectTab('products')"><a href="#products-tab">Products</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'actions') }" v-on:click="selectTab('actions')"><a href="#actions-tab">Actions</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'style') }" v-on:click="selectTab('style')"><a href="#style-tab">Style</a></li>
            </ul>

            <div class="panel-body" v-show="isActive">

                <div class="tab-content" v-bind:class="{ active: (tab == 'general') }">

                    <div class="form-group">
                        <label for="" class="form-label">Title</label>
                        <input type="text" class="form-input" v-model="notification.title">
                    </div>

                    <label for="" class="form-label">Visibility</label>

                    <p class="text-gray mr-2 mb-2">Control where to show notifications</p>

                    <div class="columns">

                        <div class="column col-xl-6 col-lg-12">

                            <div class="form-group">
                                <label class="form-switch">
                                    <input type="checkbox" v-model="notification.enableDesktop">
                                    <i class="form-icon"></i> Enable in desktop
                                </label>
                            </div>

                            <div class="form-group">
                                <label class="form-switch">
                                    <input type="checkbox" v-model="notification.enableMobile">
                                    <i class="form-icon"></i> Enable in mobile
                                </label>
                            </div>

                            <div class="form-group">
                                <label class="form-switch">
                                    <input type="checkbox" v-model="notification.enableConditionalTags">
                                    <i class="form-icon"></i> Conditional Tags
                                </label>

                                <div v-show="notification.enableConditionalTags">
                                    <p class="text-gray mt-2 mb-2">Add PHP logic to control where to show notifications</p>

                                    <div class="form-group">
                                        <input type="text" class="form-input" v-model="notification.conditionalTags" placeholder="e.g, is_single()">
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="column col-xl-6 col-lg-12">

                            <div class="form-group">
                                <label class="form-switch">
                                    <input type="checkbox" v-model="notification.hideHomePage">
                                    <i class="form-icon"></i> Hide on homepage
                                </label>
                            </div>

                            <div class="form-group">
                                <label class="form-switch">
                                    <input type="checkbox" v-model="notification.hideCheckoutPage">
                                    <i class="form-icon"></i> Hide on checkout page
                                </label>
                            </div>

                            <div class="form-group">
                                <label v-bind:for="'onHideCartPage' + notification.id" class="form-switch">
                                    <input type="checkbox" v-bind:id="'onHideCartPage' + notification.id" v-model="notification.hideCartPage">
                                    <i class="form-icon"></i> Hide on cart page
                                </label>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'messages') }">

                    <div class="form-group">
                        <label for="" class="form-label">Image</label>

                        <p class="text-gray mr-2 mb-2">Notification icon</p>

                        <div class="image-toggle">
                            <span v-for="(value, name) in images">
                                <label v-if="value.length > 0" v-bind:for="'msg-icon-' + name + notification.id" v-bind:class="[ (value === notification.image) ? 'image-toggle-active' : '' ]">
                                    <input type="radio" name="image" v-model="notification.image" v-bind:value="value" v-bind:id="'msg-icon-' + name + notification.id">
                                    <img v-bind:src="value" alt="" height="80">
                                </label>
                            </span>
                            <label class="label-btn ml-2" for="image-no" v-bind:class="[ ('fommerce-no' === notification.image) ? 'image-toggle-active' : '' ]">
                                <input type="radio" name="image" v-model="notification.image" value="fommerce-no" id="image-no">
                                No<br>Image
                            </label>
                            <?php if (is_woocommerce_activated()) { ?>
                            <label class="label-btn ml-2" for="image-product" v-bind:class="[ (notification.image.indexOf('fommerce-product') > -1) ? 'image-toggle-active' : '' ]">
                                <input type="radio" name="image" v-model="notification.image" value="<?php echo FOMMERCE_URL . 'assets/public/img/fommerce-product.svg'; ?>" id="image-product">
                                Product<br>Image
                            </label>
                            <?php } ?>
                            <label class="label-btn ml-2" v-on:click="uploadImage(['images.custom', 'notification.image'])"><div class="ft ft-plus m-0" style="font-size: 2em;"></div></label>
                        </div>
                    </div>

                    <?php

                    $editors = array(
                        'message' => array(
                            'title' => 'Message',
                            'description' => 'Primary content to show in the notification <br><b>Required *</b>'
                        ),
                        'heading' => array(
                            'title' => 'Header / Footer',
                            'description' => 'Text to show in separate header or footer of the notification'
                        ),
                        'corner' => array(
                            'title' => 'Corner',
                            'description' => 'Text to show in right corner of notification'
                        ),
                        'link' => array(
                            'title' => 'Link',
                            'description' => 'Link to the notification <br>Leave empty to disable'
                        )
                    );

                    foreach ($editors as $key => $value) {
                    ?>

                        <div class="form-group">

                        <label for="" class="form-label"><?php echo $value['title']; ?></label>

                        <p class="text-gray mr-2 mb-0"><?php echo $value['description']; ?></p>

                        <div v-bind:id="'<?php echo $key; ?>' + notification.id + '-editor'" class="editor-container"></div>
                    
                        <div class="place-inputs my-2" v-show="activeEditor == '<?php echo $key; ?>'">
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('firstname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> first name</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('firstname', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('lastname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> last name</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('lastname', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('city', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> city</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('city', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('state', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> state</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('state', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('country', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> country</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('country', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product name</div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productlink', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product link</div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productnamelink', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product name & link</div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('price', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> price</div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('date', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> date</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('date', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('timeago', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> time ago</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('timeago', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('rating', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> rating</div>
                            </div>
                            <div class="btn-group" v-show="notification.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('starrating', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> star rating</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('starrating', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('randomnumber', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> random number</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('randomnumber', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('x', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> close button</div>
                            </div>
                        </div>
                        </div>

                    <?php
                    }
                    ?>

                    <div class="modal place-modal">
                        <a href="javascript:void(0);" class="modal-overlay modal-close" aria-label="Close"></a>
                        <div class="modal-container">
                            <div class="modal-header"><a class="btn btn-clear float-right modal-close" href="javascript:void(0);" aria-label="Close"></a>
                                <div class="modal-title h5 text-warning text-bold">{{ "{" + notification.placeholder + "}" }}</div>
                            </div>
                            <div class="modal-body">

                                <div class="place-options" v-if="notification.placeholder === 'firstname'">
                                    <div class="form-group">
                                        <div>Enter names to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="notification.placeholders.firstname.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'lastname'">
                                    <div class="form-group">
                                        <div>Enter names to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="notification.placeholders.lastname.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'city'">
                                    <div class="form-group">
                                        <label class="form-switch">
                                            <input type="checkbox" v-model="notification.placeholders.city.autodetect">
                                            <i class="form-icon"></i> Autodetect from visitor
                                        </label>
                                    </div>
                                    <div class="form-group" v-if="notification.placeholders.city.autodetect === false">
                                        <div>Enter cities to be used for products without orders</div>
                                    </div>
                                    <div class="form-group" v-if="notification.placeholders.city.autodetect === false">
                                        <textarea class="form-input" v-model="notification.placeholders.city.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'state'">
                                    <div class="form-group">
                                        <div>Enter states to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="notification.placeholders.state.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'country'">
                                    <div class="form-group">
                                        <label class="form-switch">
                                            <input type="checkbox" v-model="notification.placeholders.country.autodetect">
                                            <i class="form-icon"></i> Autodetect from visitor
                                        </label>
                                    </div>
                                    <div class="form-group" v-if="notification.placeholders.country.autodetect === false">
                                        <div>Enter cities to be used for products without orders</div>
                                    </div>
                                    <div class="form-group" v-if="notification.placeholders.country.autodetect === false">
                                        <textarea class="form-input" v-model="notification.placeholders.country.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'randomnumber'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Minimum</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.randomnumber.min">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Maximum</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.randomnumber.max">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Decimals</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.randomnumber.decimals">
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'date'">
                                    <div class="form-group columns">
                                        <div class="column col-6">
                                            <label for="" class="form-label">Date Format</label>
                                            <select class="form-select" v-model="notification.placeholders.date.date">
                                                <option value="">None</option>
                                                <option value="F j, Y"><?php echo date('F j, Y'); ?></option>
                                                <option value="Y-m-d"><?php echo date('Y-m-d'); ?></option>
                                                <option value="m/d/Y"><?php echo date('m/d/Y'); ?></option>
                                                <option value="d/m/Y"><?php echo date('d/m/Y'); ?></option>
                                            </select>
                                        </div>
                                        <div class="column col-6">
                                            <label for="" class="form-label">Time Format</label>
                                            <select class="form-select" v-model="notification.placeholders.date.time">
                                                <option value="">None</option>
                                                <option value="g:i a"><?php echo date('g:i a'); ?></option>
                                                <option value="g:i A"><?php echo date('g:i A'); ?></option>
                                                <option value="H:i"><?php echo date('H:i'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Custom format (<a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">documentation</a>)</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.date.custom">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Random date</label>
                                        <div class="row">
                                            <div class="columns">
                                                <div class="column">
                                                    <input type="text" class="form-input" v-model="notification.placeholders.date.random">
                                                </div>
                                                <div class="column">
                                                    <select class="form-select" v-model="notification.placeholders.date.randomUnit">
                                                        <option value="seconds">Seconds</option>
                                                        <option value="minutes">Minutes</option>
                                                        <option value="hours">Hours</option>
                                                        <option value="days">Days</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'timeago'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Prefix</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.timeago.prefix">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Suffix</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.timeago.suffix">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Random time</label>
                                        <div class="row">
                                            <div class="columns">
                                                <div class="column">
                                                    <input type="text" class="form-input" v-model="notification.placeholders.timeago.random">
                                                </div>
                                                <div class="column">
                                                    <select class="form-select" v-model="notification.placeholders.timeago.randomUnit">
                                                        <option value="seconds">Seconds</option>
                                                        <option value="minutes">Minutes</option>
                                                        <option value="hours">Hours</option>
                                                        <option value="days">Days</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="place-options" v-if="notification.placeholder === 'starrating'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Color</label>
                                        <input type="text" class="form-input" v-model="notification.placeholders.starrating.color">
                                    </div>
                                </div>
                        
                            </div>
                        </div>
                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'products') }">

                    <div class="form-group">
                        <label for="" class="form-label">Display</label>
                        <select class="form-select" v-model="notification.products.criteria">
                            <option value="no-products">No products</option>
                            <?php if (is_woocommerce_activated()) { ?>
                            <option value="live-orders">Live orders</option>
                            <option value="orders">Products from recent orders</option>
                            <option value="select-products">Select products</option>
                            <option value="latest-products">Latest products</option>
                            <option value="select-categories">Products from select categories</option>
                            <option value="viewed-products">Recently viewed products</option>
                            <?php } ?>
                        </select>
                    </div>

                    <?php $statuses = is_woocommerce_activated() ? wc_get_order_statuses() : array(); ?>

                    <div class="form-group" v-show="notification.products.criteria == 'orders' || notification.products.criteria == 'live-orders'">
                        <label for="" class="form-label">Order Status</label>
                        <select v-bind:class="'orderstatus' + notification.id + '-selectize'" multiple>
                            <?php foreach ($statuses as $status => $name) { ?>
                            <option value="<?php echo esc_attr($status); ?>"><?php echo esc_html($name); ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria == 'orders'">
                        <label for="" class="form-label">Order Time</label>
                        <div class="row">
                            <div class="columns">
                                <div class="column col-8">
                                    <input type="number" class="form-input" v-model="notification.products.orderTime">
                                </div>
                                <div class="column col-4">
                                    <select class="form-select" v-model="notification.products.orderTimeUnit">
                                        <option value="minutes">Minutes</option>
                                        <option value="hours">Hours</option>
                                        <option value="days">Days</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria == 'select-categories'">
                        <label for="" class="form-label">Select Categories</label>
                        <select name="" v-bind:class="'category' + notification.id + '-selectize'" multiple placeholder="Type category.."></select>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria == 'select-products'">
                        <label for="" class="form-label">Select Products</label>
                        <select name="" v-bind:class="'product' + notification.id + '-selectize'" multiple placeholder="Type product name.."></select>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Limit</label>
                        <input type="number" class="form-input" v-model="notification.products.limit">
                    </div>

                    <div class="form-group" v-show="notification.products.criteria != 'no-products' && notification.products.criteria != 'select-products' && notification.products.criteria != 'viewed-products'">
                        <label for="" class="form-label">Exclude products</label>
                        <select name="" v-bind:class="'exclude' + notification.id + '-selectize'" multiple placeholder="Type product name.."></select>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria != 'no-products'">
                        <label class="form-switch">
                            <input type="checkbox" v-model="notification.products.excludeOutOfStock">
                            <i class="form-icon"></i> Exclude out of stock
                        </label>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria != 'live-orders'">
                        <label class="form-switch">
                            <input type="checkbox" v-model="notification.products.virtual">
                            <i class="form-icon"></i> Create virtual notifications
                        </label>
                    </div>

                    <div class="form-group" v-show="notification.products.criteria != 'no-products' && notification.products.criteria != 'live-orders'">
                        <label class="form-switch">
                            <input type="checkbox" v-model="notification.products.randomize">
                            <i class="form-icon"></i> Show notifications in random order
                        </label>
                    </div>
        
                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'actions') }">

                    <h5>Display</h5>
                    <hr>

                    <div class="form-group">
                        <label for="" class="form-label">Initial delay</label>
                        <div class="columns">
                            <div class="column">
                                <div class="input-group">
                                    <input type="number" class="form-input" v-model="notification.displayDelay.from" placeholder="from">
                                    <span class="input-group-addon">seconds</span>
                                </div>
                            </div>
                            <div class="column">
                                <div class="input-group">
                                    <input type="number" class="form-input" v-model="notification.displayDelay.to" placeholder="to">
                                    <span class="input-group-addon">seconds</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Display time</label>
                        <div class="input-group">
                            <input type="number" class="form-input" v-model="notification.displayTime">
                            <span class="input-group-addon">seconds</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Delay between notifications</label>
                        <div class="columns">
                            <div class="column">
                                <div class="input-group">
                                    <input type="number" class="form-input" v-model="notification.displayInterval.from" placeholder="from">
                                    <span class="input-group-addon">seconds</span>
                                </div>
                            </div>
                            <div class="column">
                                <div class="input-group">
                                    <input type="number" class="form-input" v-model="notification.displayInterval.to" placeholder="to">
                                    <span class="input-group-addon">seconds</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Number of notifications per page</label>
                        <input type="number" class="form-input" v-model="notification.displayCount">
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Sound</label>
                        <select class="form-select" v-model="notification.sound">
                            <option value="">None</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/arrival.mp3">Arrival</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/drop.mp3">Drop</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/Jump.mp3">Jump</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/shining.mp3">Shining</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/tapping.mp3">Tapping</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/triumph.mp3">Triumph</option>
                            <option value="<?php echo FOMMERCE_URL; ?>assets/public/sounds/Video.mp3">Video</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-switch">
                            <input type="checkbox" v-model="notification.loop">
                            <i class="form-icon"></i> Loop notifications
                        </label>
                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'style') }">

                    <div class="columns">
                        <div class="column col-xl-6 col-lg-12">

                            <div class="form-group">
                                <label for="" class="form-label">Design</label>
                                <div class="btn-group btn-group-block custom-toggle">
                                    <label v-bind:for="'theme-default' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-default') }">Default<input v-bind:id="'theme-default' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-default"></label>
                                    <label v-bind:for="'theme-dark' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-dark') }">Dark<input v-bind:id="'theme-dark' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-dark"></label>
                                    <label v-bind:for="'theme-ios' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-ios') }">iOS<input v-bind:id="'theme-ios' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-ios"></label>
                                    <label v-bind:for="'theme-sticky' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-sticky') }">Sticky<input v-bind:id="'theme-sticky' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-sticky"></label>
                                    <label v-bind:for="'theme-glass' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-glass') }">Glass<input v-bind:id="'theme-glass' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-glass"></label>
                                    <label v-bind:for="'theme-wood' + notification.id" class="btn" v-bind:class="{ 'active': (notification.theme == 'woo-notify-theme-wood') }">Wood<input v-bind:id="'theme-wood' + notification.id" type="radio" name="theme" v-model="notification.theme" value="woo-notify-theme-wood"></label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Position</label>
                                <div class="btn-group btn-group-block custom-toggle">
                                    <label v-bind:for="'position-top-left' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-top woo-notify-left') }"><i class="ft ft-corner-up-left"></i><input v-bind:id="'position-top-left' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-top woo-notify-left"></label>
                                    <label v-bind:for="'position-top-center' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-top woo-notify-center') }"><i class="ft ft-arrow-up"></i><input v-bind:id="'position-top-center' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-top woo-notify-center"></label>
                                    <label v-bind:for="'position-top-right' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-top woo-notify-right') }"><i class="ft ft-corner-up-right"></i><input v-bind:id="'position-top-right' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-top woo-notify-right"></label>
                                    <label v-bind:for="'position-bottom-left' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-bottom woo-notify-left') }"><i class="ft ft-corner-down-left"></i><input v-bind:id="'position-bottom-left' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-bottom woo-notify-left"></label>
                                    <label v-bind:for="'position-bottom-center' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-bottom woo-notify-center') }"><i class="ft ft-arrow-down"></i><input v-bind:id="'position-bottom-center' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-bottom woo-notify-center"></label>
                                    <label v-bind:for="'position-bottom-right' + notification.id" class="btn" v-bind:class="{ 'active': (notification.position == 'woo-notify-bottom woo-notify-right') }"><i class="ft ft-corner-down-right"></i><input v-bind:id="'position-bottom-right' + notification.id" type="radio" name="position" v-model="notification.position" value="woo-notify-bottom woo-notify-right"></label>
                                </div>
                            </div>

                            <div class="columns">
                                <div class="column">
                                    <div class="form-group">
                                        <label for="" class="form-label">Heading Position</label>
                                        <div class="btn-group btn-group-block custom-toggle">
                                            <label v-bind:for="'heading-position-top' + notification.id" class="btn" v-bind:class="{ 'active': (notification.headingPosition == 'flex-column') }"><i class="ft ft-arrow-up"></i><input v-bind:id="'heading-position-top' + notification.id" type="radio" name="heading-position" v-model="notification.headingPosition" value="flex-column"></label>
                                            <label v-bind:for="'heading-position-bottom' + notification.id" class="btn" v-bind:class="{ 'active': (notification.headingPosition == 'flex-column-reverse') }"><i class="ft ft-arrow-down"></i><input v-bind:id="'heading-position-bottom' + notification.id" type="radio" name="heading-position" v-model="notification.headingPosition" value="flex-column-reverse"></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="form-group">
                                        <label for="" class="form-label">Image Position</label>
                                        <div class="btn-group btn-group-block custom-toggle">
                                            <label v-bind:for="'image-position-left' + notification.id" class="btn" v-bind:class="{ 'active': (notification.imagePosition == 'woo-notify-content-avatar-left') }"><i class="ft ft-arrow-left"></i><input v-bind:id="'image-position-left' + notification.id" type="radio" name="image-position" v-model="notification.imagePosition" value="woo-notify-content-avatar-left"></label>
                                            <label v-bind:for="'image-position-right' + notification.id" class="btn" v-bind:class="{ 'active': (notification.imagePosition == 'woo-notify-content-avatar-right') }"><i class="ft ft-arrow-right"></i><input v-bind:id="'image-position-right' + notification.id" type="radio" name="image-position" v-model="notification.imagePosition" value="woo-notify-content-avatar-right"></label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Text Color</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'text' + notification.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: notification.textColor }"></div>
                                    <input type="text" class="form-input" v-model="notification.textColor">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Background</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'bg' + notification.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: notification.background }"></div>
                                    <div class="input-group-addon flex-centered c-hand" v-on:click="uploadImage(['notification.background'])"><i class="ft ft-image mr-2"></i> Choose Image</div>
                                    <input type="text" class="form-input" v-model="notification.background">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="" class="form-label">Image Background</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'img-bg' + notification.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: notification.imageBackground }"></div>
                                    <input type="text" class="form-input" v-model="notification.imageBackground">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Width</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="1000" v-model="notification.width" v-bind:data-value="notification.width" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Border Radius</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="notification.borderRadius" v-bind:data-value="notification.borderRadius" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="columns">
                                <div class="column">
                                    <div class="form-group">
                                        <label for="" class="form-label">Font</label>
                                        <select class="form-input form-select" v-model="notification.font">
                                            <option value="default">Theme Default</option>
                                            <?php foreach($this->data->fonts as $font) { ?>
                                                <option value="<?php echo $font; ?>"><?php echo $font; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="column">
                                    <div class="form-group">
                                        <label for="" class="form-label">Font Size</label>
                                        <div class="input-group">
                                            <input type="number" class="form-input" v-model="notification.fontSize">
                                            <div class="input-group-addon">px</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="column col-xl-6 col-lg-12">

                            <div class="form-group">
                                <label for="" class="form-label">Margin</label>

                                <div class="columns">
                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-more-vertical"></i></div>
                                        <input type="number" class="form-input" v-model="notification.margin.vertical">
                                    </div>

                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-more-horizontal"></i></div>
                                        <input type="number" class="form-input" v-model="notification.margin.horizontal">
                                    </div>
                                </div>

                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Padding</label>

                                <div class="columns">
                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-arrow-up"></i></div>
                                        <input type="number" class="form-input" v-model="notification.padding.top">
                                    </div>

                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-arrow-right"></i></div>
                                        <input type="number" class="form-input" v-model="notification.padding.right">
                                    </div>

                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-arrow-down"></i></div>
                                        <input type="number" class="form-input" v-model="notification.padding.bottom">
                                    </div>

                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-arrow-left"></i></div>
                                        <input type="number" class="form-input" v-model="notification.padding.left">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Size</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="200" v-model="notification.imageSize" v-bind:data-value="notification.imageSize" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="columns">
                                <div class="form-group column">
                                    <label for="" class="form-label">Image Margin</label>
                                    <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="notification.imageMargin" v-bind:data-value="notification.imageMargin" oninput="this.setAttribute('value', this.value);">
                                </div>
                                <div class="form-group column">
                                    <label for="" class="form-label">Image Padding</label>
                                    <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="notification.imagePadding" v-bind:data-value="notification.imagePadding" oninput="this.setAttribute('value', this.value);">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Entry Animation</label>
                                <select class="form-select" v-model="notification.entryAnim">

                                    <optgroup label="Fading Entrances">
                                        <option value="fadeIn">fadeIn</option>
                                    </optgroup>
                    
                                    <optgroup label="Bouncing Entrances">
                                        <option value="bounceIn">bounceIn</option>
                                        <option value="bounceDownIn">bounceInDown</option>
                                        <option value="bounceLeftIn">bounceInLeft</option>
                                        <option value="bounceRightIn">bounceInRight</option>
                                        <option value="bounceUpIn">bounceInUp</option>
                                    </optgroup>
                    
                                    <optgroup label="Flippers">
                                        <option value="flipXIn">flipInX</option>
                                        <option value="flipYIn">flipInY</option>
                                        <option value="flipBounceXIn">flipInBounceX</option>
                                        <option value="flipBounceYIn">flipInBounceY</option>
                                    </optgroup>

                                    <optgroup label="Sliding Entrances">
                                        <option value="slideUpIn">slideInUp</option>
                                        <option value="slideDownIn">slideInDown</option>
                                        <option value="slideLeftIn">slideInLeft</option>
                                        <option value="slideRightIn">slideInRight</option>
                                    </optgroup>

                                    <optgroup label="Perspective Entrances">
                                        <option value="perspectiveUpIn">perspectiveInUp</option>
                                        <option value="perspectiveDownIn">perspectiveInDown</option>
                                        <option value="perspectiveLeftIn">perspectiveInLeft</option>
                                        <option value="perspectiveRightIn">perspectiveInRight</option>
                                    </optgroup>

                                    <optgroup label="Swoop">
                                        <option value="swoopIn">swoopIn</option>
                                    </optgroup>

                                    <optgroup label="Whirl">
                                        <option value="whirlIn">whirlIn</option>
                                    </optgroup>

                                    <optgroup label="Shrink">
                                        <option value="shrinkIn">shrinkIn</option>
                                    </optgroup>

                                    <optgroup label="Expand">
                                        <option value="expandIn">expandIn</option>
                                    </optgroup>

                                </select>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Exit Animation</label>
                                <select class="form-select" v-model="notification.exitAnim">

                                    <optgroup label="Fading Exits">
                                        <option value="fadeOut">fadeOut</option>
                                    </optgroup> 
                    
                                    <optgroup label="Bouncing Exits">
                                        <option value="bounceOut">bounceOut</option>
                                        <option value="bounceDownOut">bounceOutDown</option>
                                        <option value="bounceLeftOut">bounceOutLeft</option>
                                        <option value="bounceRightOut">bounceOutRight</option>
                                        <option value="bounceUpOut">bounceOutUp</option>
                                    </optgroup>
                    
                                    <optgroup label="Flippers">
                                        <option value="flipXOut">flipOutX</option>
                                        <option value="flipYOut">flipOutY</option>
                                        <option value="flipBounceXOut">flipOutBounceX</option>
                                        <option value="flipBounceYOut">flipOutBounceY</option>
                                    </optgroup>

                                    <optgroup label="Sliding Exits">
                                        <option value="slideUpOut">slideOutUp</option>
                                        <option value="slideDownOut">slideOutDown</option>
                                        <option value="slideLeftOut">slideOutLeft</option>
                                        <option value="slideRightOut">slideOutRight</option>
                                    </optgroup>

                                    <optgroup label="Perspective Exits">
                                        <option value="perspectiveUpOut">perspectiveOutUp</option>
                                        <option value="perspectiveDownOut">perspectiveOutDown</option>
                                        <option value="perspectiveLeftOut">perspectiveOutLeft</option>
                                        <option value="perspectiveRightOut">perspectiveOutRight</option>
                                    </optgroup>

                                    <optgroup label="Swoop">
                                        <option value="swoopOut">swoopOut</option>
                                    </optgroup>

                                    <optgroup label="Whirl">
                                        <option value="whirlOut">whirlOut</option>
                                    </optgroup>

                                    <optgroup label="Shrink">
                                        <option value="shrinkOut">shrinkOut</option>
                                    </optgroup>

                                    <optgroup label="Expand">
                                        <option value="expandOut">expandOut</option>
                                    </optgroup>

                                </select>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Animation Speed</label>
                                <select class="form-select" v-model="notification.animSpeed">
                                    <option value="500">Faster</option>
                                    <option value="800">Fast</option>
                                    <option value="1000">Normal</option>
                                    <option value="2000">Slow</option>
                                    <option value="3000">Slower</option>
                                </select>
                            </div>

                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>

</template>