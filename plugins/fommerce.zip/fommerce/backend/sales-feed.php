<h1 class="wp-heading-inline mb-2">Sales Feed</h1>
<hr class="wp-header-end">

<template id="fommerce-feeds">

    <div class="template-content">

        <div class="panel mt-2">

            <div class="panel-header">
                <div class="panel-title" v-on:dblclick="$parent.toggle(feed.id)">
                    <label class="form-switch d-inline-block">
                        <input type="checkbox" v-model="feed.active">
                        <i class="form-icon"></i> {{ feed.title }}
                    </label>
                    <div>
                        <div v-bind:id="'feed' + feed.id + '-shortcode'" :data-clipboard-text="shortcode" v-html="shortcode" class="panel-btn panel-btn-text"></div>
                        <div v-on:click="$parent.toggle(feed.id)" class="panel-btn"><i class="ft ft-minimize" v-if="isActive"></i><i class="ft ft-maximize" v-else></i></div>
                        <div v-on:click="$parent.remove(feed.id)" class="panel-btn"><i class="ft ft-trash"></i></div>
                    </div>
                </div>
            </div>

            <ul class="tab tab-block" v-show="isActive">
                <li class="tab-item" v-bind:class="{ active: (tab == 'general') }" v-on:click="selectTab('general')"><a href="#general-tab">General</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'messages') }" v-on:click="selectTab('messages')"><a href="#messages-tab">Messages</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'products') }" v-on:click="selectTab('products')"><a href="#products-tab">Products</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'style') }" v-on:click="selectTab('style')"><a href="#style-tab">Style</a></li>
            </ul>

            <div class="live-preview live-preview-feeds" v-show="isActive">
                <div class="preview-content" v-bind:class="'preview-content-' + feed.id">
                    <div class="fomo-feeds" v-bind:class="'fomo-feeds-' + feed.id" v-bind:style="containerStyle">
                        <div class="fomo-feed-slide" v-for="n in 10" v-bind:key="n">
                            <div class="woo-notify" v-bind:class="[feed.theme]" v-bind:style="notifyStyle">
                                <div class="woo-notify-row woo-notify-body">
                                    <div class="woo-notify-content-avatar" v-bind:class="feed.imagePosition" v-bind:style="imageContainerStyle">
                                        <img v-bind:src="feed.image" alt="" v-if="feed.image.indexOf('fommerce-no') == -1" v-bind:style="imageStyle">
                                    </div>
                                    <div class="woo-notify-content" v-bind:style="textStyle">
                                        <div class="woo-notify-content-text" v-html="feed.message"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="preview-toggle flex-centered" v-on:click="$parent.togglePreview()"><span><i class="ft ft-eye"></i> Preview</span></div>
            </div>

            <div class="panel-body" v-show="isActive">

                <div class="tab-content" v-bind:class="{ active: (tab == 'general') }">

                    <div class="form-group">
                        <label for="" class="form-label">Title</label>
                        <input type="text" class="form-input" v-model="feed.title">
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Slides to show</label>
                        <input type="number" class="form-input" v-model="feed.slidesToShow">
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Slides to scroll</label>
                        <input type="number" class="form-input" v-model="feed.slidesToScroll">
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Scroll Interval</label>
                        <div class="input-group">
                            <input type="number" step="0.1" class="form-input" v-model="feed.interval">
                            <span class="input-group-addon">seconds</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Direction</label>
                        <select class="form-select" v-model="feed.direction">
                            <option value="up">Up</option>
                            <option value="down">Down</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-switch">
                            <input type="checkbox" v-model="feed.autoplay">
                            <i class="form-icon"></i> Automatically scroll slides
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-switch">
                            <input type="checkbox" v-model="feed.loop">
                            <i class="form-icon"></i> Loop slides
                        </label>
                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'messages') }">

                    <div class="form-group">
                        <label for="" class="form-label">Image</label>

                        <div class="image-toggle">
                            <span v-for="(value, name) in images">
                                <label v-if="value.length > 0" v-bind:for="'msg-icon-' + name + feed.id" v-bind:class="[ (value === feed.image) ? 'image-toggle-active' : '' ]">
                                    <input type="radio" name="image" v-model="feed.image" v-bind:value="value" v-bind:id="'msg-icon-' + name + feed.id">
                                    <img v-bind:src="value" alt="" height="80">
                                </label>
                            </span>
                            <label class="label-btn ml-2" for="image-no" v-bind:class="[ ('fommerce-no' === feed.image) ? 'image-toggle-active' : '' ]">
                                <input type="radio" name="image" v-model="feed.image" value="fommerce-no" id="image-no">
                                No<br>Image
                            </label>
                            <?php if (is_woocommerce_activated()) { ?>
                            <label class="label-btn ml-2" for="image-product" v-bind:class="[ (feed.image.indexOf('fommerce-product') > -1) ? 'image-toggle-active' : '' ]">
                                <input type="radio" name="image" v-model="feed.image" value="<?php echo FOMMERCE_URL . 'assets/public/img/fommerce-product.svg'; ?>" id="image-product">
                                Product<br>Image
                            </label>
                            <?php } ?>
                            <label class="label-btn ml-2" v-on:click="uploadImage(['images.custom', 'feed.image'])"><div class="ft ft-plus m-0" style="font-size: 2em;"></div></label>
                        </div>
                    </div>

                <?php

                    $editors = array(
                        'message' => array(
                            'title' => 'Message',
                            'description' => 'Primary content to show in the feed <br><b>Required *</b>'
                        ),
                        'link' => array(
                            'title' => 'Link',
                            'description' => 'Link to each slide <br>Leave empty to disabl'
                        )
                    );

                    foreach ($editors as $key => $value) {
                    ?>

                        <div class="form-group">

                        <label for="" class="form-label"><?php echo $value['title']; ?></label>

                        <p class="text-gray mr-2 mb-0"><?php echo $value['description']; ?></p>

                        <div v-bind:id="'<?php echo $key; ?>' + feed.id + '-editor'" class="editor-container"></div>

                        <div class="place-inputs my-2" v-show="activeEditor == '<?php echo $key; ?>'">
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('firstname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> first name</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('firstname', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('lastname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> last name</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('lastname', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('city', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> city</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('city', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('state', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> state</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('state', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('country', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> country</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('country', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productname', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product name</div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productlink', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product link</div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('productnamelink', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> product name & link</div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('price', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> price</div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('date', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> date</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('date', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('timeago', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> time ago</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('timeago', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('rating', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> rating</div>
                            </div>
                            <div class="btn-group" v-show="feed.products.criteria!=='no-products'">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('starrating', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> star rating</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('starrating', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('randomnumber', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> random number</div>
                                <div class="btn btn-sm" v-on:click="editPlaceholder('randomnumber', '<?php echo $key; ?>')"><i class="ft ft-edit"></i></div>
                            </div>
                            <div class="btn-group">
                                <div class="btn btn-sm" v-on:click="insertPlaceholder('x', '<?php echo $key; ?>')"><i class="ft ft-plus"></i> close button</div>
                            </div>
                        </div>
                        </div>

                    <?php } ?>

                    <div class="modal place-modal">
                        <a href="javascript:void(0);" class="modal-overlay modal-close" aria-label="Close"></a>
                        <div class="modal-container">
                            <div class="modal-header"><a class="btn btn-clear float-right modal-close" href="javascript:void(0);" aria-label="Close"></a>
                                <div class="modal-title h5 text-warning text-bold">{{ "{" + feed.placeholder + "}" }}</div>
                            </div>
                            <div class="modal-body">

                                <div class="place-options" v-if="feed.placeholder === 'firstname'">
                                    <div class="form-group">
                                        <div>Enter names to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="feed.placeholders.firstname.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'lastname'">
                                    <div class="form-group">
                                        <div>Enter names to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="feed.placeholders.lastname.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'city'">
                                    <div class="form-group">
                                        <label class="form-switch">
                                            <input type="checkbox" v-model="feed.placeholders.city.autodetect">
                                            <i class="form-icon"></i> Autodetect from visitor
                                        </label>
                                    </div>
                                    <div class="form-group" v-if="feed.placeholders.city.autodetect === false">
                                        <div>Enter cities to be used for products without orders</div>
                                    </div>
                                    <div class="form-group" v-if="feed.placeholders.city.autodetect === false">
                                        <textarea class="form-input" v-model="feed.placeholders.city.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'state'">
                                    <div class="form-group">
                                        <div>Enter states to be used for products without orders</div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-input" v-model="feed.placeholders.state.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'country'">
                                    <div class="form-group">
                                        <label class="form-switch">
                                            <input type="checkbox" v-model="feed.placeholders.country.autodetect">
                                            <i class="form-icon"></i> Autodetect from visitor
                                        </label>
                                    </div>
                                    <div class="form-group" v-if="feed.placeholders.country.autodetect === false">
                                        <div>Enter cities to be used for products without orders</div>
                                    </div>
                                    <div class="form-group" v-if="feed.placeholders.country.autodetect === false">
                                        <textarea class="form-input" v-model="feed.placeholders.country.list" v-on:input="resizeTextarea" ref="textarea"></textarea>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'randomnumber'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Minimum</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.randomnumber.min">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Maximum</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.randomnumber.max">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Decimals</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.randomnumber.decimals">
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'date'">
                                    <div class="form-group columns">
                                        <div class="column col-6">
                                            <label for="" class="form-label">Date Format</label>
                                            <select class="form-select" v-model="feed.placeholders.date.date">
                                                <option value="">None</option>
                                                <option value="F j, Y"><?php echo date('F j, Y'); ?></option>
                                                <option value="Y-m-d"><?php echo date('Y-m-d'); ?></option>
                                                <option value="m/d/Y"><?php echo date('m/d/Y'); ?></option>
                                                <option value="d/m/Y"><?php echo date('d/m/Y'); ?></option>
                                            </select>
                                        </div>
                                        <div class="column col-6">
                                            <label for="" class="form-label">Time Format</label>
                                            <select class="form-select" v-model="feed.placeholders.date.time">
                                                <option value="">None</option>
                                                <option value="g:i a"><?php echo date('g:i a'); ?></option>
                                                <option value="g:i A"><?php echo date('g:i A'); ?></option>
                                                <option value="H:i"><?php echo date('H:i'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Custom format (<a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">documentation</a>)</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.date.custom">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Random date</label>
                                        <div class="row">
                                            <div class="columns">
                                                <div class="column">
                                                    <input type="text" class="form-input" v-model="feed.placeholders.date.random">
                                                </div>
                                                <div class="column">
                                                    <select class="form-select" v-model="feed.placeholders.date.randomUnit">
                                                        <option value="seconds">Seconds</option>
                                                        <option value="minutes">Minutes</option>
                                                        <option value="hours">Hours</option>
                                                        <option value="days">Days</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'timeago'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Prefix</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.timeago.prefix">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Suffix</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.timeago.suffix">
                                    </div>
                                    <div class="form-group">
                                        <label for="" class="form-label">Random time</label>
                                        <div class="row">
                                            <div class="columns">
                                                <div class="column">
                                                    <input type="text" class="form-input" v-model="feed.placeholders.timeago.random">
                                                </div>
                                                <div class="column">
                                                    <select class="form-select" v-model="feed.placeholders.timeago.randomUnit">
                                                        <option value="seconds">Seconds</option>
                                                        <option value="minutes">Minutes</option>
                                                        <option value="hours">Hours</option>
                                                        <option value="days">Days</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="place-options" v-if="feed.placeholder === 'starrating'">
                                    <div class="form-group">
                                        <label for="" class="form-label">Color</label>
                                        <input type="text" class="form-input" v-model="feed.placeholders.starrating.color">
                                    </div>
                                </div>
                        
                            </div>
                        </div>
                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'products') }">

                    <div class="form-group">
                        <label for="" class="form-label">Display</label>
                        <select class="form-select" v-model="feed.products.criteria">
                            <option value="no-products">No products</option>
                            <?php if (is_woocommerce_activated()) { ?>
                            <option value="live-orders">Live orders</option>
                            <option value="orders">Products from recent orders</option>
                            <option value="select-products">Select products</option>
                            <option value="latest-products">Latest products</option>
                            <option value="select-categories">Products from select categories</option>
                            <option value="viewed-products">Recently viewed products</option>
                            <?php } ?>
                        </select>
                    </div>

                    <?php $statuses = is_woocommerce_activated() ? wc_get_order_statuses() : array(); ?>

                    <div class="form-group" v-show="feed.products.criteria == 'orders' || feed.products.criteria == 'live-orders'">
                        <label for="" class="form-label">Order Status</label>
                        <select v-bind:class="'orderstatus' + feed.id + '-selectize'" multiple>
                            <?php foreach ($statuses as $status => $name) { ?>
                            <option value="<?php echo esc_attr($status); ?>"><?php echo esc_html($name); ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group" v-show="feed.products.criteria == 'orders'">
                        <label for="" class="form-label">Order Time</label>
                        <div class="row">
                            <div class="columns">
                                <div class="column col-8">
                                    <input type="number" class="form-input" v-model="feed.products.orderTime">
                                </div>
                                <div class="column col-4">
                                    <select class="form-select" v-model="feed.products.orderTimeUnit">
                                        <option value="minutes">Minutes</option>
                                        <option value="hours">Hours</option>
                                        <option value="days">Days</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" v-show="feed.products.criteria == 'select-categories'">
                        <label for="" class="form-label">Select Categories</label>
                        <select name="" v-bind:class="'category' + feed.id + '-selectize'" multiple placeholder="Type category.."></select>
                    </div>

                    <div class="form-group" v-show="feed.products.criteria == 'select-products'">
                        <label for="" class="form-label">Select Products</label>
                        <select name="" v-bind:class="'product' + feed.id + '-selectize'" multiple placeholder="Type product name.."></select>
                    </div>

                    <div class="form-group" v-show="feed.products.criteria != 'no-products' && feed.products.criteria != 'select-products'">
                        <label for="" class="form-label">Limit</label>
                        <input type="number" class="form-input" v-model="feed.products.limit">
                    </div>

                    <div class="form-group" v-show="feed.products.criteria != 'no-products' && feed.products.criteria != 'select-products' && feed.products.criteria != 'viewed-products'">
                        <label for="" class="form-label">Exclude products</label>
                        <select name="" v-bind:class="'exclude' + feed.id + '-selectize'" multiple placeholder="Type product name.."></select>
                    </div>

                    <div class="form-group" v-show="feed.products.criteria != 'no-products'">
                        <label class="form-switch">
                            <input type="checkbox" v-model="feed.products.excludeOutOfStock">
                            <i class="form-icon"></i> Exclude out of stock
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-switch">
                            <input type="checkbox" v-model="feed.products.virtual">
                            <i class="form-icon"></i> Create virtual notifications
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-switch">
                            <input type="checkbox" v-model="feed.products.randomize">
                            <i class="form-icon"></i> Show products in random order
                        </label>
                    </div>
        
                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'style') }">

                    <div class="columns">
                        <div class="column">

                            <div class="form-group">
                                <label for="" class="form-label">Theme</label>
                                <div class="btn-group btn-group-block custom-toggle">
                                    <label v-bind:for="'theme-default' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-default') }">Default<input v-bind:id="'theme-default' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-default"></label>
                                    <label v-bind:for="'theme-dark' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-dark') }">Dark<input v-bind:id="'theme-dark' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-dark"></label>
                                    <label v-bind:for="'theme-ios' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-ios') }">iOS<input v-bind:id="'theme-ios' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-ios"></label>
                                    <label v-bind:for="'theme-sticky' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-sticky') }">Sticky<input v-bind:id="'theme-sticky' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-sticky"></label>
                                    <label v-bind:for="'theme-glass' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-glass') }">Glass<input v-bind:id="'theme-glass' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-glass"></label>
                                    <label v-bind:for="'theme-wood' + feed.id" class="btn" v-bind:class="{ 'active': (feed.theme == 'woo-notify-theme-wood') }">Wood<input v-bind:id="'theme-wood' + feed.id" type="radio" name="theme" v-model="feed.theme" value="woo-notify-theme-wood"></label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Border Radius</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.borderRadius" v-bind:data-value="feed.borderRadius" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Border Color</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'border' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.borderColor }"></div>
                                    <input type="text" class="form-input" v-model="feed.borderColor">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Border</label>

                                <div class="row">
                                    <div class="columns">
                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-up"></i></div>
                                            <input type="number" class="form-input" v-model="feed.border.top">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-right"></i></div>
                                            <input type="number" class="form-input" v-model="feed.border.right">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-down"></i></div>
                                            <input type="number" class="form-input" v-model="feed.border.bottom">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-left"></i></div>
                                            <input type="number" class="form-input" v-model="feed.border.left">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Box Shadow</label>
                                <div class="input-group">
                                    <div class="input-group-addon c-hand" v-on:click="$parent.toggleModal('.box-shadow-modal')"><i class="ft ft-edit-3"></i> Edit</div>
                                    <input type="text" class="form-input" v-model="feed.shadow.text">
                                </div>
                            </div>

                            <div class="modal box-shadow-modal">
                                <a href="javascript:void(0);" class="modal-overlay modal-close" aria-label="Close"></a>
                                <div class="modal-container">
                                    <div class="modal-header"><a class="btn btn-clear float-right modal-close" href="javascript:void(0);" aria-label="Close"></a>
                                        <div class="modal-title h5 text-warning text-bold">Box Shadow</div>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label class="form-switch">
                                                <input type="checkbox" v-model="feed.shadow.enabled">
                                                <i class="form-icon"></i> Enable
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Blur</label>
                                            <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.shadow.blur" v-bind:data-value="feed.shadow.blur" oninput="this.setAttribute('value', this.value);">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Spread</label>
                                            <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.shadow.spread" v-bind:data-value="feed.shadow.spread" oninput="this.setAttribute('value', this.value);">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Horizontal</label>
                                            <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.shadow.horizontal" v-bind:data-value="feed.shadow.horizontal" oninput="this.setAttribute('value', this.value);">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Vertical</label>
                                            <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.shadow.vertical" v-bind:data-value="feed.shadow.vertical" oninput="this.setAttribute('value', this.value);">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="form-label">Color</label>
                                            <div class="input-group">
                                                <div class="btn input-group-btn" v-bind:class="'shadow' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.shadow.color }"></div>
                                                <input type="text" class="form-input" v-model="feed.shadow.color">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Text Color</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'text' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.textColor }"></div>
                                    <input type="text" class="form-input" v-model="feed.textColor">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Background</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'img-bg' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.imageBackground }"></div>
                                    <div class="input-group-addon flex-centered c-hand" v-on:click="uploadImage('feed.imageBackground')"><i class="ft ft-image mr-2"></i> Choose Image</div>
                                    <input type="text" class="form-input" v-model="feed.imageBackground">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Slide Background</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'slide-bg' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.slideBackground }"></div>
                                    <div class="input-group-addon flex-centered c-hand" v-on:click="uploadImage('feed.slideBackground')"><i class="ft ft-image mr-2"></i> Choose Image</div>
                                    <input type="text" class="form-input" v-model="feed.slideBackground">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Widget Background</label>
                                <div class="input-group">
                                    <div class="btn input-group-btn" v-bind:class="'widget-bg' + feed.id + '-colorpicker'" style="padding: 0 1rem;border: 1px solid rgba(0,0,0,0.1);" v-bind:style="{ background: feed.widgetBackground }"></div>
                                    <div class="input-group-addon flex-centered c-hand" v-on:click="uploadImage('feed.widgetBackground')"><i class="ft ft-image mr-2"></i> Choose Image</div>
                                    <input type="text" class="form-input" v-model="feed.widgetBackground">
                                </div>
                            </div>

                        </div>

                        <div class="column">

                            <div class="form-group">
                                <label for="" class="form-label">Spacing</label>

                                <div class="columns">
                                    <div class="input-group column">
                                        <div class="input-group-addon"><i class="ft ft-more-vertical"></i></div>
                                        <input type="number" class="form-input" v-model="feed.spacing">
                                    </div>
                                </div>

                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Padding</label>

                                <div class="row">
                                    <div class="columns">
                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-up"></i></div>
                                            <input type="number" class="form-input" v-model="feed.padding.top">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-right"></i></div>
                                            <input type="number" class="form-input" v-model="feed.padding.right">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-down"></i></div>
                                            <input type="number" class="form-input" v-model="feed.padding.bottom">
                                        </div>

                                        <div class="input-group column">
                                            <div class="input-group-addon"><i class="ft ft-arrow-left"></i></div>
                                            <input type="number" class="form-input" v-model="feed.padding.left">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Font</label>
                                <select class="form-input form-select" v-model="feed.font">
                                    <option value="default">Theme Default</option>
                                    <?php foreach($this->data->fonts as $font) { ?>
                                        <option value="<?php echo $font; ?>"><?php echo $font; ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Font Size</label>
                                <div class="input-group">
                                    <input type="number" class="form-input" v-model="feed.fontSize">
                                    <div class="input-group-addon">px</div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Position</label>
                                <div class="btn-group btn-group-block custom-toggle">
                                    <label v-bind:for="'image-position-left' + feed.id" class="btn" v-bind:class="{ 'active': (feed.imagePosition == 'woo-notify-content-avatar-left') }"><i class="ft ft-arrow-left"></i><input v-bind:id="'image-position-left' + feed.id" type="radio" name="image-position" v-model="feed.imagePosition" value="woo-notify-content-avatar-left"></label>
                                    <label v-bind:for="'image-position-right' + feed.id" class="btn" v-bind:class="{ 'active': (feed.imagePosition == 'woo-notify-content-avatar-right') }"><i class="ft ft-arrow-right"></i><input v-bind:id="'image-position-right' + feed.id" type="radio" name="image-position" v-model="feed.imagePosition" value="woo-notify-content-avatar-right"></label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Size</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="200" v-model="feed.imageSize" v-bind:data-value="feed.imageSize" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Margin</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.imageMargin" v-bind:data-value="feed.imageMargin" oninput="this.setAttribute('value', this.value);">
                            </div>

                            <div class="form-group">
                                <label for="" class="form-label">Image Padding</label>
                                <input class="slider tooltip tooltip-bottom" type="range" min="0" max="100" v-model="feed.imagePadding" v-bind:data-value="feed.imagePadding" oninput="this.setAttribute('value', this.value);">
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</template>