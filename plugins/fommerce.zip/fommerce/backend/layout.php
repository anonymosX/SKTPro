<div id="fommerce" class="fmcs">

    <div class="menu-section">
        <ul class="menu">
            <li class="menu-item">
                <img src="<?php echo FOMMERCE_URL . 'assets/admin/img/logo.png'; ?>" alt="">
            </li>
            <li class="divider" data-content=""></li>
            <?php if ($this->data->options['config']['license'] === 'regular' || $this->data->options['config']['license'] === 'extended') { ?>
            <li class="menu-item">
                <a href="<?php echo admin_url('admin.php?page=fommerce&addon=notifications'); ?>"<?php if ($this->addon == 'notifications') { ?> class="active"<?php } ?>><i class="ft ft-message-square mx-1"></i> Notifications</a>
            </li>
            <li class="menu-item">
                <a href="<?php echo admin_url('admin.php?page=fommerce&addon=sales-feed'); ?>"<?php if ($this->addon == 'sales-feed') { ?> class="active"<?php } ?>><i class="ft ft-server mx-1"></i> Sales Feed</a>
            </li>
            <?php } ?>
            <li class="menu-item">
                <a href="<?php echo admin_url('admin.php?page=fommerce&addon=settings'); ?>"<?php if ($this->addon == 'settings') { ?> class="active"<?php } ?>><i class="ft ft-settings mx-1"></i> Settings</a>
            </li>
        </ul>
    </div>

    <div class="wrap">

        <?php require_once(FOMMERCE_PATH . 'backend/' . $this->addon . '.php'); ?>

        <div id="fommerce-app">

            <?php if ($this->data->options['config']['license'] === 'regular' || $this->data->options['config']['license'] === 'extended') { ?>
            
            <?php if ($this->addon == 'notifications') { ?>
            
            <div class="panel mt-2" v-if="notifications.length == 0">
                <div class="panel-header">
                    <div class="panel-title">
                        No notifications created yet.
                    </div>
                </div>
            </div>

            <fommerce-notifications v-for="notification in notifications" :key="notification.id" :notification="notification" :selected="selected"></fommerce-notifications>

            <?php } ?>

            <?php if ($this->addon == 'sales-feed') { ?>

            <div class="panel mt-2" v-if="feeds.length == 0">
                <div class="panel-header">
                    <div class="panel-title">
                        No sales feeds created yet.
                    </div>
                </div>
            </div>

            <fommerce-feeds v-for="feed in feeds" :key="feed.id" :feed="feed" :selected="selected"></fommerce-feeds>

            <?php } ?>

            <?php } ?>

            <?php if ($this->addon == 'settings') { ?>
            <fommerce-config :config="config"></fommerce-config>
            <?php } ?>

            <br>

            <?php wp_nonce_field('fommerce_editor', '_fmcnonce'); ?>

            <button v-on:click="submit()" class="btn btn-success flex-centered"><i class="ft ft-save mr-1"></i> Save Changes</button>

            <?php if ($this->addon != 'settings') { ?>
            <button v-on:click="addpanel()" class="btn btn-primary flex-centered ml-2"><i class="ft ft-plus mr-1"></i> Add New</button>
            <?php } ?>

        </div>

    </div>

</div>