<h1 class="wp-heading-inline">Settings</h1>
<hr class="wp-header-end">

<template id="fommerce-config">

    <div class="template-content">

        <div class="panel mt-2">

            <div class="panel-header">
                <div class="panel-title">Settings</div>
            </div>

            <ul class="tab tab-block">
                <li class="tab-item" v-bind:class="{ active: (tab == 'license') }" v-on:click="selectTab('license')"><a href="#license-tab">License</a></li>
                <li class="tab-item" v-bind:class="{ active: (tab == 'help') }" v-on:click="selectTab('help')"><a href="#general-tab">Help</a></li>
            </ul>

            <div class="panel-body">

                <div class="tab-content" v-bind:class="{ active: (tab == 'license') }">

                    <div class="toast" v-show="message.length > 0">
                        <button class="btn btn-clear float-right"></button>
                        <span v-html="message"></span>
                    </div>           

                    <p>Enter your purchase code below to activate your copy.</p>

                    <p>Activating the plugin unlocks additional settings, automatic future updates, and support from developers.</p>

                    <div class="form-group" v-if="config.license==='false'">
                        <label for="" class="form-label">Status</label>
                        <div class="label label-default">Inactive</div> - You are not receiving automatic updates
                    </div>

                    <div class="form-group" v-else>
                        <label for="" class="form-label">Status</label>
                        <div class="label label-success">Active</div> - You are receiving automatic updates
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Purchase Code <a class="float-right" href="https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-" target="_blank">Where is my purchase code?</a></label>
                        <input type="text" class="form-input" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" v-model="config.licenseKey">
                        <input type="hidden" v-model="config.license">
                    </div>

                    <div class="form-group mb-0">
                        <button class="btn btn-success" v-if="config.license==='false'" v-on:click="licenseCheck('activate')">Activate</button>
                        <button class="btn" v-else v-on:click="licenseCheck('deactivate')">Deactivate</button>
                    </div>

                </div>

                <div class="tab-content" v-bind:class="{ active: (tab == 'help') }">
                    <b>Activating the plugin</b>
                    <ol>
                        <li>Go to <a href="https://codecanyon.net/downloads" target="_blank">https://codecanyon.net/downloads</a></li>
                        <li>Click on Downloads &gt; License certificate and purchase code (text) and copy the purchase code</li>
                        <li>Enter the purchase code in License tab on this page and click Activate</li>
                    </ol>

                    <!-- <b>Documentation</b>
                    <br>
                    <ul>
                        <li>Full documentation is available <a href="https://docs.blocksera.com/fommerce">here</a></li>
                    </ul> -->
                </div>

            </div>

        </div>

    </div>

</template>