<?php
/**
 * Index file
 *
 * @package Shoptimizer
 * @since Shoptimizer 1.0.0
 */

/* Silence is golden, and we agree. */
