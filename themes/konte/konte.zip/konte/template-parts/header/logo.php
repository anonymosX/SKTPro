<?php
/**
 * Template part for displaying the logo
 *
 * @package Konte
 */

$logo_type = konte_get_option( 'logo_type' );

if ( 'text' == $logo_type ) :
	$logo = konte_get_option( 'logo_text' );
elseif ( 'svg' == $logo_type ) :
	$logo = konte_get_option( 'logo_svg' );
else:
	$logo       = konte_get_option( 'logo' );
	$logo_light = konte_get_option( 'logo_light' );

	if ( ! $logo && ! $logo_light ) {
		$logo       = $logo ? $logo : get_theme_file_uri( '/images/logo.svg' );
		$logo_light = $logo_light ? $logo_light : get_theme_file_uri( '/images/logo-light.svg' );
	} elseif ( ! $logo_light && $logo ) {
		$logo_light = $logo;
	} elseif ( ! $logo && $logo_light ) {
		$logo = $logo_light;
	}

	$dimension = konte_get_option( 'logo_dimension' );
	$width     = ( 0 < intval( $dimension['width'] ) ) ? ' width="' . intval( $dimension['width'] ) . '"' : '';
	$height    = ( 0 < intval( $dimension['width'] ) ) ? ' height="' . intval( $dimension['height'] ) . '"' : '';
endif;
?>
<div class="site-branding">
	<a href="<?php echo esc_url( home_url() ) ?>" class="logo">
		<?php if ( 'text' == $logo_type ) : ?>
			<span class="logo-text"><?php echo esc_html( $logo ) ?></span>
		<?php elseif ( 'svg' == $logo_type ) : ?>
			<span class="logo-svg"><?php echo konte_sanitize_svg( $logo ); ?></span>
		<?php else : ?>
			<img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" class="logo-dark" <?php echo trim( $width . $height ); ?>>
			<img src="<?php echo esc_url( $logo_light ); ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" class="logo-light" <?php echo trim( $width . $height ); ?>>
		<?php endif; ?>
	</a>

	<?php if ( is_front_page() || is_home() ) : ?>
		<h1 class="site-title">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
		</h1>
	<?php else : ?>
		<p class="site-title">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
		</p>
	<?php endif; ?>

	<?php if ( ( $description = get_bloginfo( 'description', 'display' ) ) || is_customize_preview() ) : ?>
		<p class="site-description"><?php echo wp_kses_post( $description ); ?></p>
	<?php endif; ?>
</div>
