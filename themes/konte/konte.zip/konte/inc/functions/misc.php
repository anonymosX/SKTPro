<?php
/**
 * Misc functions for this theme
 *
 * @package Konte
 */

/**
 * Get translated object ID if the WPML plugin is installed
 * Return the original ID if this plugin is not installed
 *
 * @param int    $id            The object ID
 * @param string $type          The object type 'post', 'page', 'post_tag', 'category' or 'attachment'. Default is 'page'
 * @param bool   $original      Set as 'true' if you want WPML to return the ID of the original language element if the translation is missing.
 * @param bool   $language_code If set, forces the language of the returned object and can be different than the displayed language.
 *
 * @return mixed
 */
function konte_get_translated_object_id( $id, $type = 'page', $original = true, $language_code = null ) {
	if ( function_exists( 'konte_addons_get_translated_object_id' ) ) {
		return konte_addons_get_translated_object_id( $id, $type, $original, $language_code );
	} elseif ( function_exists( 'wpml_object_id_filter' ) ) {
		$id = wpml_object_id_filter( $id, $type, $original, $language_code );
	} elseif ( function_exists( 'icl_object_id' ) ) {
		$id = icl_object_id( $id, $type, $original, $language_code );
	}

	return apply_filters( 'wpml_object_id', $id, $type, $original, $language_code );
}

/**
 * Get Instagram images
 *
 * @param int $limit
 *
 * @return array|WP_Error
 */
function konte_get_instagram_images( $limit = 12 ) {
	$access_token = konte_get_option( 'api_instagram_token' );

	if ( empty( $access_token ) ) {
		return new WP_Error( 'instagram_no_access_token', esc_html__( 'No access token', 'konte' ) );
	}

	$user = konte_get_instagram_user();

	if ( ! $user || is_wp_error( $user ) ) {
		return $user;
	}

	$transient_key = 'konte_instagram_photos_' . sanitize_title_with_dashes( $user['username'] . '__' . $limit );
	$images = get_transient( $transient_key );

	if ( false === $images || empty( $images ) ) {
		$url = add_query_arg( array(
			'count'        => $limit,
			'access_token' => $access_token,
		), 'https://api.instagram.com/v1/users/self/media/recent/' );

		$remote = wp_remote_retrieve_body( wp_remote_get( $url ) );
		$data   = json_decode( $remote, true );
		$images = array();

		if ( $data['meta']['code'] == 200 ) {
			foreach ( $data['data'] as $media ) {
				$images[] = array(
					'caption'  => $media['caption'],
					'link'     => $media['link'],
					'time'     => $media['created_time'],
					'comments' => $media['comments']['count'],
					'likes'    => $media['likes']['count'],
					'images'   => $media['images'],
				);
			}

			if ( ! empty( $images ) ) {
				set_transient( $transient_key, $images, 2 * 3600 );
			}
		} else {
			return new WP_Error( 'instagram_error', $data['meta']['error_message'] );
		}
	}

	if ( ! empty( $images ) ) {
		return $images;
	} else {
		return new WP_Error( 'instagram_no_images', esc_html__( 'Instagram did not return any images.', 'konte' ) );
	}
}

/**
 * Get user data
 *
 * @return bool|WP_Error|array
 */
function konte_get_instagram_user() {
	$access_token = konte_get_option( 'api_instagram_token' );

	if ( empty( $access_token ) ) {
		return new WP_Error( 'no_access_token', esc_html__( 'No access token', 'konte' ) );
	}

	$user = get_transient( 'konte_instagram_user' );

	if ( false === $user ) {
		$url  = add_query_arg( array( 'access_token' => $access_token ), 'https://api.instagram.com/v1/users/self/' );
		$data = wp_remote_get( $url );
		$data = wp_remote_retrieve_body( $data );

		if ( ! $data ) {
			return new WP_Error( 'no_user_data', esc_html__( 'No user data received', 'konte' ) );
		}

		$data = json_decode( $data, true );
		$user = isset( $data['data'] ) ? $data['data'] : false;

		set_transient( 'konte_instagram_user', $user );
	}

	return $user;
}

/**
 * Sanitize SVG code.
 *
 * @param string $svg SVG code.
 *
 * @return string
 */
function konte_sanitize_svg( $svg ) {
	$allowed   = array();
	$whitelist = array(
		'a'              => array(
			'class',
			'clip-path',
			'clip-rule',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'mask',
			'opacity',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
			'href',
			'xlink:href',
			'xlink:title',
		),
		'circle'         => array(
			'class',
			'clip-path',
			'clip-rule',
			'cx',
			'cy',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'mask',
			'opacity',
			'r',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
		),
		'clipPath'       => array( 'class', 'clipPathUnits', 'id' ),
		'defs'           => array(),
		'style'          => array( 'type' ),
		'desc'           => array(),
		'ellipse'        => array(
			'class',
			'clip-path',
			'clip-rule',
			'cx',
			'cy',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'mask',
			'opacity',
			'requiredFeatures',
			'rx',
			'ry',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
		),
		'feGaussianBlur' => array( 'class', 'color-interpolation-filters', 'id', 'requiredFeatures', 'stdDeviation' ),
		'filter'         => array(
			'class',
			'color-interpolation-filters',
			'filterRes',
			'filterUnits',
			'height',
			'id',
			'primitiveUnits',
			'requiredFeatures',
			'width',
			'x',
			'xlink:href',
			'y',
		),
		'foreignObject'  => array(
			'class',
			'font-size',
			'height',
			'id',
			'opacity',
			'requiredFeatures',
			'style',
			'transform',
			'width',
			'x',
			'y',
		),
		'g'              => array(
			'class',
			'clip-path',
			'clip-rule',
			'id',
			'display',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'mask',
			'opacity',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
			'font-family',
			'font-size',
			'font-style',
			'font-weight',
			'text-anchor',
		),
		'image'          => array(
			'class',
			'clip-path',
			'clip-rule',
			'filter',
			'height',
			'id',
			'mask',
			'opacity',
			'requiredFeatures',
			'style',
			'systemLanguage',
			'transform',
			'width',
			'x',
			'xlink:href',
			'xlink:title',
			'y',
		),
		'line'           => array(
			'class',
			'clip-path',
			'clip-rule',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'marker-end',
			'marker-mid',
			'marker-start',
			'mask',
			'opacity',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
			'x1',
			'x2',
			'y1',
			'y2',
		),
		'linearGradient' => array(
			'class',
			'id',
			'gradientTransform',
			'gradientUnits',
			'requiredFeatures',
			'spreadMethod',
			'systemLanguage',
			'x1',
			'x2',
			'xlink:href',
			'y1',
			'y2',
		),
		'marker'         => array(
			'id',
			'class',
			'markerHeight',
			'markerUnits',
			'markerWidth',
			'orient',
			'preserveAspectRatio',
			'refX',
			'refY',
			'systemLanguage',
			'viewBox',
		),
		'mask'           => array( 'class', 'height', 'id', 'maskContentUnits', 'maskUnits', 'width', 'x', 'y' ),
		'metadata'       => array( 'class', 'id' ),
		'path'           => array(
			'class',
			'clip-path',
			'clip-rule',
			'd',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'marker-end',
			'marker-mid',
			'marker-start',
			'mask',
			'opacity',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
		),
		'pattern'        => array(
			'class',
			'height',
			'id',
			'patternContentUnits',
			'patternTransform',
			'patternUnits',
			'requiredFeatures',
			'style',
			'systemLanguage',
			'viewBox',
			'width',
			'x',
			'xlink:href',
			'y',
		),
		'polygon'        => array(
			'class',
			'clip-path',
			'clip-rule',
			'id',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'id',
			'class',
			'marker-end',
			'marker-mid',
			'marker-start',
			'mask',
			'opacity',
			'points',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
		),
		'polyline'       => array(
			'class',
			'clip-path',
			'clip-rule',
			'id',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'marker-end',
			'marker-mid',
			'marker-start',
			'mask',
			'opacity',
			'points',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
		),
		'radialGradient' => array(
			'class',
			'cx',
			'cy',
			'fx',
			'fy',
			'gradientTransform',
			'gradientUnits',
			'id',
			'r',
			'requiredFeatures',
			'spreadMethod',
			'systemLanguage',
			'xlink:href',
		),
		'rect'           => array(
			'class',
			'clip-path',
			'clip-rule',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'height',
			'id',
			'mask',
			'opacity',
			'requiredFeatures',
			'rx',
			'ry',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
			'width',
			'x',
			'y',
		),
		'stop'           => array(
			'class',
			'id',
			'offset',
			'requiredFeatures',
			'stop-color',
			'stop-opacity',
			'style',
			'systemLanguage',
		),
		'svg'            => array(
			'class',
			'clip-path',
			'clip-rule',
			'filter',
			'id',
			'mask',
			'preserveaspectRatio',
			'requiredfeatures',
			'style',
			'systemlanguage',
			'viewbox',
			'width',
			'height',
			'xmlns',
			'xmlns:se',
			'xmlns:xlink',
			'x',
			'y',
			'enable-background',
		),
		'switch'         => array( 'class', 'id', 'requiredFeatures', 'systemLanguage' ),
		'symbol'         => array(
			'class',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'font-family',
			'font-size',
			'font-style',
			'font-weight',
			'id',
			'opacity',
			'preserveAspectRatio',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'transform',
			'viewBox',
		),
		'text'           => array(
			'class',
			'clip-path',
			'clip-rule',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'font-family',
			'font-size',
			'font-style',
			'font-weight',
			'id',
			'mask',
			'opacity',
			'requiredFeatures',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'text-anchor',
			'transform',
			'x',
			'xml:space',
			'y',
		),
		'textPath'       => array(
			'class',
			'id',
			'method',
			'requiredFeatures',
			'spacing',
			'startOffset',
			'style',
			'systemLanguage',
			'transform',
			'xlink:href',
		),
		'title'          => array(),
		'tspan'          => array(
			'class',
			'clip-path',
			'clip-rule',
			'dx',
			'dy',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'font-family',
			'font-size',
			'font-style',
			'font-weight',
			'id',
			'mask',
			'opacity',
			'requiredFeatures',
			'rotate',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'systemLanguage',
			'text-anchor',
			'textLength',
			'transform',
			'x',
			'xml:space',
			'y',
		),
		'use'            => array(
			'class',
			'clip-path',
			'clip-rule',
			'fill',
			'fill-opacity',
			'fill-rule',
			'filter',
			'height',
			'id',
			'mask',
			'stroke',
			'stroke-dasharray',
			'stroke-dashoffset',
			'stroke-linecap',
			'stroke-linejoin',
			'stroke-miterlimit',
			'stroke-opacity',
			'stroke-width',
			'style',
			'transform',
			'width',
			'x',
			'xlink:href',
			'y',
		),
	);

	foreach ( $whitelist as $tag => $attributes ) {
		$allowed[ $tag ] = array();

		foreach ( $attributes as $attribute ) {
			$allowed[ $tag ][ $attribute ] = true;
		}
	}

	return wp_kses( $svg, $allowed );
}

/**
 * Get Youtube video ID.
 *
 * @see https://gist.github.com/ghalusa/6c7f3a00fd2383e5ef33
 */
function konte_get_youtube_video_id( $video_url ) {
	preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $video_url, $match );

	return $match[1];
}

/**
 * Conditional function to check if current page is the maintenance page.
 *
 * @return bool
 */
function konte_is_maintenance_page() {
	if ( ! konte_get_option( 'maintenance_enable' ) ) {
		return false;
	}

	if ( current_user_can( 'super admin' ) ) {
		return false;
	}

	$page_id = konte_get_option( 'maintenance_page' );

	if ( ! $page_id ) {
		return false;
	}

	return is_page( $page_id );
}

if ( ! function_exists( 'konte_svg_icon' ) ) :
	/**
	 * Return SVG markup.
	 *
	 * @param array $args
	 *
	 * @return string
	 */
	function konte_svg_icon( $args = array() ) {
		$args = wp_parse_args( $args, array(
			'icon'     => '',
			'size'     => 'normal',
			'class'    => '',
			'title'    => '',
			'desc'     => '',
			'fallback' => '',
			'echo'     => true,
		) );

		// Begin SVG markup.
		$svg = '<span class="svg-icon icon-' . esc_attr( $args['icon'] ) . ' size-' . esc_attr( $args['size'] ) . ' ' . esc_attr( $args['class'] ) . '"><svg role="img">';

		// Display the title.
		if ( $args['title'] ) {
			$unique_id = uniqid();
			$svg       .= '<title id="title-' . $unique_id . '">' . esc_html( $args['title'] ) . '</title>';

			// Display the desc only if the title is already set.
			if ( $args['desc'] ) {
				$svg .= '<desc id="desc-' . $unique_id . '">' . esc_html( $args['desc'] ) . '</desc>';
			}
		}

		$svg .= ' <use href="#' . esc_html( $args['icon'] ) . '" xlink:href="#' . esc_html( $args['icon'] ) . '"></use> ';

		// Add some markup to use as a fallback for browsers that do not support SVGs.
		if ( $args['fallback'] ) {
			$svg .= '<span class="svg-fallback ' . esc_attr( $args['fallback'] ) . '"></span>';
		}

		$svg .= '</svg></span>';

		if ( ! $args['echo'] ) {
			return $svg;
		}

		echo ! empty( $svg ) ? $svg : '';
	}
endif;

if ( ! function_exists( 'konte_remove_empty_p' ) ) :
	/**
	 * Remove empty paragraphs.
	 *
	 * @param string $content
	 * @return string
	 */
	function konte_remove_empty_p( $content ) {
		return preg_replace( '#<p>\s*+(<br\s*/*>)?\s*</p>#i', '', $content );
	}
endif;

if ( ! function_exists( 'wp_body_open' ) ) {
	/**
	 * Adds backwards compatibility for wp_body_open() introduced with WordPress 5.2
	 *
	 * @since 1.6.3
	 * @see https://developer.wordpress.org/reference/functions/wp_body_open/
	 */
	function wp_body_open() {
		do_action( 'wp_body_open' );
	}
}